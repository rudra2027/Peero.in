<?php

$showAlert = false; 
$showSuccess = false; 

session_start(); 
include_once 'config.php';$message=$_POST["message"];
if(isset($_POST['submit'])){
    
    $que  = "SELECT * FROM users WHERE id = '".$_SESSION["id"]."'";
    $result = mysqli_query($conn, $que);
        if(mysqli_num_rows($result) == 1){
          while ($row = mysqli_fetch_assoc($result)){
             
    $query = "UPDATE users SET `message` =('$message')  WHERE id = '".$_SESSION["id"]."'";
    $upd=mysqli_query($conn, $query) or die(mysqli_error($mysqli));
$showSuccess=true;}              

}
//     if($query){echo'success';}
// else{echo'error';}
}
?>
<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Peero-Education</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/x-icon" href="img/favicon.ico">
    <!-- Place favicon.ico in the root directory -->

    <!-- CSS here -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="fontawesome/css/all.min.css">
    <link rel="stylesheet" href="font-flaticon/flaticon.css">
    <link rel="stylesheet" href="css/dripicons.css">
    <link rel="stylesheet" href="css/slick.css">
    <link rel="stylesheet" href="css/meanmenu.css">
    <link rel="stylesheet" href="css/default.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window,document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '178286547560625'); 
fbq('track', 'PageView');
</script>
<noscript>
<img height="1" width="1" 
src="https://www.facebook.com/tr?id=178286547560625&ev=PageView
&noscript=1"/>
</noscript>
<!-- End Facebook Pixel Code -->

</head>

<body>
    <!-- header -->
    <header class="header-area header-three">
        <div id="header-sticky" class="menu-area">
            <div class="container">
                <div class="second-menu">
                    <div class="row align-items-center">
                        <div class="col-xl-2 col-lg-2">
                            <div class="logo">
                                <a href="index.php"><img src="img/logo/logo.png" alt="logo"></a>
                            </div>
                        </div>
                        <div class="col-xl-8 col-lg-8">

                            <div class="main-menu text-right text-xl-right">
                                <nav id="mobile-menu" style="display: block;">
                                    <ul>
                                    <li class="sub">
                                            <a href="index.php">Home</a>
                                        </li>
                                        <li class="sub"><a href="about.php">About Us</a></li>
                                        <li class="sub">
                                            <a href="competetion.php">Olympiads</a>
                                            <ul>
                                                <li>
                                                    <a href="english.php ">English</a>
                                                </li>
                                                <li>
                                                    <a href="science.php ">Science</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <!-- <li class="sub">
                                            <a href="events.html">Events</a>
                                            <ul>
                                                <li><a href="events.html">Events</a></li>
                                                <li><a href="events-details.html">Events Details</a></li>
                                            </ul>
                                        </li>

                                        <li class="sub"><a href="#">Pages</a>
                                            <ul>
                                                <li><a href="projects.html">Gallery</a></li>
                                                <li><a href="projects-detail.html">Gallery Details</a></li>

                                                <li><a href="pricing.html">Pricing</a></li>
                                                <li><a href="team.html">Team</a></li>
                                                <li><a href="faq.html">Faq</a></li>
                                                <li><a href="shop.html">Shop</a></li>
                                                <li><a href="shop-details.html">Shop Details</a>
                                                </li>
                                            </ul>
                                        </li>

                                        <li class="sub">
                                            <a href="blog.html">News</a>
                                            <ul>
                                                <li><a href="blog.html">News</a></li>
                                                <li><a href="blog-details.html">News Details</a></li>
                                            </ul>
                                        </li> -->

                                       
                                        <li><a href="contact.php">Contact</a></li> 
                                     <li> <a href="logout.php">Logout</a></li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        <div class="col-xl-2 col-lg-2 text-right d-none d-xl-block mt-30 mb-30">
                            <div class="search-top2">
                                <ul>

                                    <li><a href="#" class="menu-tigger"><i class="fas fa-search"style="display:none"></i></a></li>
                                    <li>
                                        <a href="#" class="menu-tigger"><img src="img/icon/menu.png" alt="logo"></a>
                                    </li>
                                </ul>
                            </div>
                        </div>


                        <div class="col-12">
                            <div class="mobile-menu"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- header-end -->
    <!-- offcanvas-area -->
    <div class="offcanvas-menu">
        <span class="menu-close"><i class="fas fa-times"></i></span>
        <form role="search" method="get" id="searchform" class="searchform" action="http://wordpress.zcube.in/xconsulta/">
            <input type="text" name="s" id="search" value="" placeholder="Search" />
            <button><i class="fa fa-search"></i></button>
        </form>


        <div id="cssmenu3" class="menu-one-page-menu-container">
            <ul id="menu-one-page-menu-2" class="menu">
                <li class="menu-item menu-item-type-custom menu-item-object-custom">
                    <a href="competetion.php">Olympiads</a>
                </li>
                <li class="menu-item menu-item-type-custom menu-item-object-custom"><a href="index.php">Home</a></li>
                <li class="menu-item menu-item-type-custom menu-item-object-custom"><a href="about.php">About Us</a></li>
                
                <!-- <li class="menu-item menu-item-type-custom menu-item-object-custom"><a href="pricing.html">Pricing </a></li>
                <li class="menu-item menu-item-type-custom menu-item-object-custom"><a href="team.html">Team </a></li>

                <li class="menu-item menu-item-type-custom menu-item-object-custom"><a href="projects.html">Gallery Study</a></li>
                <li class="menu-item menu-item-type-custom menu-item-object-custom"><a href="blog.html">Blog</a></li> -->
                <li class="menu-item menu-item-type-custom menu-item-object-custom"> <a href="logout.php">Logout</a></li>
                <li class="menu-item menu-item-type-custom menu-item-object-custom"><a href="contact.php">Contact</a></li>
            </ul>
        </div>

        <div id="cssmenu2" class="menu-one-page-menu-container">
            <ul id="menu-one-page-menu-1" class="menu">

                <li class="menu-item menu-item-type-custom menu-item-object-custom"><a href="#home"><span>+91 9571538998</span></a></li>
                <li class="menu-item menu-item-type-custom menu-item-object-custom"><a href="#howitwork"><span>hello@peero.in</span></a></li>
            </ul>
        </div>
    </div>
    <div class="offcanvas-overly"></div>
    <!-- offcanvas-end -->
    <!-- main-area -->
    <main>

        <!-- search-popup -->
        <div class="modal fade bs-example-modal-lg search-bg popup1" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content search-popup">
                    <div class="text-center">
                        <a href="#" class="close2" data-dismiss="modal" aria-label="Close">× close</a>
                    </div>
                    <div class="row search-outer">
                        <div class="col-md-11"><input type="text" placeholder="Search for products..." /></div>
                        <div class="col-md-1 text-right"><a href="#"><i class="fa fa-search" aria-hidden="true"></i></a></div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /search-popup -->
        <!-- breadcrumb-area -->
        <section class="breadcrumb-area d-flex align-items-center" style="background-image:url(img/testimonial/test-bg.png)">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-xl-12 col-lg-12">
                        <div class="breadcrumb-wrap text-left">
                            <div class="breadcrumb-title">
                                <h2>Contact Us</h2>
                                <div class="breadcrumb-wrap">

                                    <nav aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                            <li class="breadcrumb-item active" aria-current="page">Contact Us</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>
        <!-- breadcrumb-area-end -->
 
        <!-- services-area -->
        <section id="services" class="services-area pt-120 pb-90 fix" style=" background-image: url(img/bg/blog-bg-aliments.png); background-repeat: no-repeat; background-position: center center;background-attachment: fixed;">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section-title center-align text-center mb-50">
                            <h5>Contact</h5>
                            <h2>
                                Get In Touch
                            </h2>
                        </div>

                    </div>

                </div>
                <div class="row">
                    <div class="col-lg-4 col-md-12">

                        <div class="services-box mt-0 mb-30 text-center">
                            <div class="services-icon">
                                <img src="img/icon/cn-icon1.png" alt="icon01">
                            </div>
                            <div class="services-content2">
                                <h5>Email Address</h5>
                                <p>hello@peero.in</p>
                            </div>
                        </div>
                        <div class="services-box mt-0 mb-30 text-center">
                            <div class="services-icon">
                                <img src="img/icon/cn-icon2.png" alt="icon01">
                            </div>
                            <div class="services-content2">
                                <h5>Phone Number</h5>
                                <p>+91 9571538998</p>

                            </div>
                        </div>
                        <div class="services-box mt-0 mb-30 text-center">
                            <div class="services-icon">
                                <img src="img/icon/cn-icon3.png" alt="icon01">
                            </div>
                            <div class="services-content2">
                                <h5>Office Address</h5>
                                <p>No.9, 2nd Floor, Kaveri Mansion, HAL, Bangalore, 560017</p>

                            </div>
                        </div>


                    </div>
                    
                    <div class="col-lg-8 col-md-12">

                        <form action="contact.php" method="POST" class="contact-form ">
                            <div class="row">
                                <!--<div class="col-lg-12">-->
                                <!--    <div class="contact-field p-relative c-name mb-20">-->
                                <!--        <input type="text" id="firstn" name="firstn" placeholder="First Name" required>-->
                                <!--    </div>-->
                                <!--</div>-->
                                <!--<div class="col-lg-12">-->
                                <!--    <div class="contact-field p-relative c-email mb-20">-->
                                <!--        <input type="text" id="lastn" name="lastn" placeholder="Last Name" required>-->
                                <!--    </div>-->
                                <!--</div>-->
                                <!--<div class="col-lg-12">-->
                                <!--    <div class="contact-field p-relative c-subject mb-20">-->
                                <!--        <input type="text" id="email" name="email" placeholder="Email" required>-->
                                <!--    </div>-->
                                <!--</div>-->
                                <!--<div class="col-lg-12">-->
                                <!--    <div class="contact-field p-relative c-subject mb-20">-->
                                <!--        <input type="text" id="phone" name="phone" placeholder="Phone No." required>-->
                                <!--    </div>-->
                                <!--</div>-->
                                <!-- <div class="col-lg-12">
                                    <div class="contact-field p-relative c-option mb-20">
                                        <select name="services" id="sr">
                                      <option value="sports-massage">Sports Massage</option>
                                      <option value="hot-stone-message">Hot Stone Message</option>
                                      <option value="facil-therophy">Facil & Therophy</option>
                                    </select>
                                    </div>
                                </div> -->
                                <div class="col-lg-12">
                                    <div class="contact-field p-relative c-message mb-45">
                                        <textarea name="message" id="message" cols="30" rows="10" placeholder="Write comments"></textarea>
                                    </div>
                                    <div class="slider-btn">
                                        <button class="btn ss-btn" name="submit" data-animation="fadeInRight" data-delay=".8s">Submit Now</button>
                                    </div>
                                     <?php
                                    if($showSuccess){ echo ' <div class="alert alert-success 
                                        alert-dismissible fade show" role="alert">
                                
                                        <strong>Success!</strong> Your Query Has Been Submitted.
                                        <button type="button" class="close"
                                            data-dismiss="alert" aria-label="Close"> 
                                            <span aria-hidden="true">×</span> 
                                        </button> 
                                    </div> ';}
                                    
                                    
                                    
                                    ?>
                                </div>
                            </div>

                        </form>

                    </div>


                </div>
            </div>
        </section>
        <!-- services-area-end -->

        <!-- services-area -->
        <!-- <section id="map" class="map fix">
            <div class="container-fulid">
                <div class="row">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d425345.01307524694!2d-112.40523132230999!3d33.60509911295008!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x872b12ed50a179cb%3A0x8c69c7f8354a1bac!2sPhoenix%2C%20AZ%2C%20USA!5e0!3m2!1sen!2sin!4v1616492655751!5m2!1sen!2sin"
                        width="100" height="600" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                </div>
            </div>
        </section> -->


    </main>
    <!-- main-area-end -->
    <!-- footer -->
    <footer class="footer-bg footer-p fix" style=" background-image: url(img/bg/footer-bg.png); background-repeat: no-repeat; background-position: center;">
        <div class="footer-top  pt-70 pb-40">
            <div class="container">
                <div class="row">
                    <div class="col-xl-3 col-lg-3 col-sm-12">
                        <div class="footer-widget mb-30">

                            <img src="img/logo/f_logo.png" alt="img">

                        </div>
                    </div>
                    <div class="col-xl-7 col-lg-7 col-sm-12">
                        <div class="footer-widget footer-link mt-20 text-center">
                            <ul>
                                <li><a href="index.php">Home</a></li>
                                <li><a href="about.php"> About Us</a></li>
                                <li><a href="competetion.php">Olympiads</a></li>
                                <!-- <li><a href="contact.html"> Events</a></li>
                                <li><a href="blog.html">Blog </a></li> -->
                                <li><a href="contact.php">Contact Us </a></li>
                            </ul>


                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-2 col-sm-12">
                        <div class="footer-widget footer-social mt-15  text-right text-xl-right">
                            <a href="https://www.facebook.com/PeerO.in/ "><i class="fab fa-facebook-f "></i></a>
                            <a href="https://www.instagram.com/peero.in/"><i class="fab fa-instagram "></i></a>
                            <!-- <a href="#"><i class="fab fa-twitter"></i></a> -->

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-center  pt-70 pb-40">
            <div class="container">
                <div class="row justify-content-between">

                    <div class="col-xl-3 col-lg-3 col-sm-6">
                        <div class="footer-widget mb-30">
                            <div class="f-widget-title">
                                <h2>About Us</h2>
                            </div>
                            <div class="footer-link">
                                Need something? Peer’O is here to help. For any queries please contact us on our details below

                            </div>

                        </div>
                    </div>

                    <div class="col-xl-3 col-lg-3 col-sm-6">
                        <div class="footer-widget mb-30">
                            <div class="f-widget-title">
                                <h2>Contact Us</h2>
                            </div>
                            <div class="f-contact">
                                <ul>
                                    <li>
                                        <i class="icon fal fa-map-marker-check "></i>
                                        <span>No.9, 2nd Floor, Kaveri Mansion, HAL, Bangalore, 560017</span>
                                    </li>
                                    <li>
                                        <i class="icon fal fa-phone "></i>
                                        <span>+91 9571538998<br></span>
                                    </li>
                                    <li><i class="icon fal fa-envelope "></i>
                                        <span>
                                            <a href="mailto:info@example.com ">hello@peero.in</a>
                                       <br>
                                       <!-- <a href="mailto:help@example.com ">help@example.com</a> -->
                                       </span>
                                    </li>

                                </ul>

                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-sm-6">
                        <div class="footer-widget mb-30">
                            <div class="f-widget-title">
                                <h2>Our Services</h2>
                            </div>
                            <div class="footer-link">
                                <ul>
                                    <li><a href="index.php">Home</a></li>
                                    <li><a href="about.php"> About Us</a></li>
                                    <li><a href="competetion.php"> Olympiads</a></li>
                                    <li><a href="contact.php"> Contact Us</a></li>
                                    <!-- <li><a href="blog.html">Blog </a></li> -->
                                </ul>
                            </div>
                        </div>
                    </div>


                    <!-- <div class="col-xl-3 col-lg-3 col-sm-6">
                        <div class="footer-widget mb-30">
                            <div class="f-widget-title">
                                <h2>Our Gallery</h2>
                            </div>
                            <div class="f-insta">
                                <ul>
                                    <li>
                                        <a href="img/instagram/f-galler-01.png" class=" popup-image"><img src="img/instagram/f-galler-01.png" alt="img"></a>
                                    </li>
                                    <li>
                                        <a href="img/instagram/f-galler-02.png" class=" popup-image"><img src="img/instagram/f-galler-02.png" alt="img"></a>
                                    </li>
                                    <li>
                                        <a href="img/instagram/f-galler-03.png" class=" popup-image"><img src="img/instagram/f-galler-03.png" alt="img"></a>
                                    </li>
                                    <li>
                                        <a href="img/instagram/f-galler-04.png" class=" popup-image"><img src="img/instagram/f-galler-04.png" alt="img"></a>
                                    </li>

                                </ul>
                            </div>
                        </div>
                    </div> -->

                </div>
            </div>
        </div>
        <div class="copyright-wrap">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6 ">
                        Copyright &copy; 2021 Peero. All rights reserved.
                    </div>
                    <div class="col-lg-6 text-right text-xl-right ">
                        <ul>
                            <li><a href="# ">Privacy</a></li>
                            <li><a href="# ">Term & Conditions</a></li>
                            <li><a href="# ">Legal</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- footer-end -->


    <!-- JS here -->
    <script src="js/vendor/modernizr-3.5.0.min.js"></script>
    <script src="js/vendor/jquery-1.12.4.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/one-page-nav-min.js"></script>
    <script src="js/slick.min.js"></script>
    <script src="js/ajax-form.js"></script>
    <script src="js/paroller.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/js_isotope.pkgd.min.js"></script>
    <script src="js/imagesloaded.min.js"></script>
    <script src="js/parallax.min.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.counterup.min.js"></script>
    <script src="js/jquery.scrollUp.min.js"></script>
    <script src="js/jquery.meanmenu.min.js"></script>
    <script src="js/parallax-scroll.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/element-in-view.js"></script>
    <script src="js/main.js"></script>
</body>

</html>