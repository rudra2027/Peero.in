<?php

session_start();




?>
<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Peero-Education</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/x-icon" href="img/favicon.ico">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <!-- Place favicon.ico in the root directory -->

    <!-- CSS here -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="fontawesome/css/all.min.css">
    <link rel="stylesheet" href="font-flaticon/flaticon.css">
    <link rel="stylesheet" href="css/dripicons.css">
    <link rel="stylesheet" href="css/slick.css">
    <link rel="stylesheet" href="css/meanmenu.css">
    <link rel="stylesheet" href="css/default.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window,document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '178286547560625'); 
fbq('track', 'PageView');
</script>
<noscript>
<img height="1" width="1" 
src="https://www.facebook.com/tr?id=178286547560625&ev=PageView
&noscript=1"/>
</noscript>
<!-- End Facebook Pixel Code -->

</head>

<body>
    <!-- header -->
    <header class="header-area header-three">
        <div id="header-sticky" class="menu-area">
            <div class="container">
                <div class="second-menu">
                    <div class="row align-items-center">
                        <div class="col-xl-2 col-lg-2">
                            <div class="logo">
                                <a href="index.html"><img src="img/logo/logo.png" alt="logo"></a>
                            </div>
                        </div>
                        <div class="col-xl-8 col-lg-8">

                            <div class="main-menu text-right text-xl-right">
                                <nav id="mobile-menu" style="display: block;">
                                    <ul>
                                        <li class="sub">
                                            <a href="index.php">Home</a>
                                        </li>
                                        <li class="sub"><a href="about.php">About Us</a></li>
                                        <li class="sub">
                                            <a href="competetion.php">Olympiads</a>
                                            <ul>
                                                <li>
                                                    <a href="english.php ">English</a>
                                                </li>
                                                <li>
                                                    <a href="science.php ">Science</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <!-- <li class="sub ">
                                            <a href="events.html ">Events</a>
                                            <ul>
                                                <li><a href="events.html ">Events</a></li>
                                                <li><a href="events-details.html ">Events Details</a></li>
                                            </ul>
                                        </li>

                                        <li class="sub "><a href="# ">Pages</a>
                                            <ul>
                                                <li><a href="projects.html ">Gallery</a></li>
                                                <li><a href="projects-detail.html ">Gallery Details</a></li>

                                                <li><a href="pricing.html ">Pricing</a></li>
                                                <li><a href="team.html ">Team</a></li>
                                                <li><a href="faq.html ">Faq</a></li>
                                                <li><a href="shop.html ">Shop</a></li>
                                                <li><a href="shop-details.html ">Shop Details</a>
                                                </li>
                                            </ul>
                                        </li>

                                        <li class="sub ">
                                            <a href="# ">News</a>
                                            <ul>
                                                <li><a href="# ">News</a></li>
                                                <li><a href="# ">News Details</a></li>
                                            </ul>
                                        </li> -->


                                        <li class="sub "><a href="contact.php ">Contact</a></li>
                                        <li class="sub ">
                                        <!-- <li class="nav-item active"> -->
        <a class="nav-link" href="#"> <img src="https://img.icons8.com/metro/26/000000/guest-male.png"> <?php echo "Welcome ". $_SESSION['username']?></a>
      </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        <div class="col-xl-2 col-lg-2 text-right d-none d-xl-block mt-30 mb-30 ">
                            <div class="search-top2 ">
                                <ul>

                                    <li>
                                        <a href="# " class="menu-tigger "></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="# " class="menu-tigger "><img src="img/icon/menu.png " alt="logo "></a>
                                    </li>
                                </ul>
                            </div>
                        </div>


                        <div class="col-12 ">
                            <div class="mobile-menu "></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- header-end -->
    <!-- offcanvas-area -->
    <div class="offcanvas-menu ">
        <span class="menu-close "><i class="fas fa-times "></i></span>
        <form role="search " method="get " id="searchform " class="searchform " action="http://wordpress.zcube.in/xconsulta/ ">
            <input type="text " name="s " id="search " value=" " placeholder="Search " />
            <button><i class="fa fa-search "></i></button>
        </form>


        <div id="cssmenu3 " class="menu-one-page-menu-container ">
            <ul id="menu-one-page-menu-2 " class="menu "> 
                <li class="menu-item menu-item-type-custom menu-item-object-custom "><a href="competetion.php "><span>Olympiads</span></a></li>
                <li class="menu-item menu-item-type-custom menu-item-object-custom "><a href="index.php ">Home</a></li>
                <li class="menu-item menu-item-type-custom menu-item-object-custom "><a href="about.php ">About Us</a></li>
               
                <!-- <li class="menu-item menu-item-type-custom menu-item-object-custom "><a href="services.html ">Services</a></li>
                <li class="menu-item menu-item-type-custom menu-item-object-custom "><a href="pricing.html ">Pricing </a></li>
                <li class="menu-item menu-item-type-custom menu-item-object-custom "><a href="team.html ">Team </a></li>

                <li class="menu-item menu-item-type-custom menu-item-object-custom "><a href="projects.html ">Gallery Study</a></li>
                <li class="menu-item menu-item-type-custom menu-item-object-custom "> <a href="# ">Quizes</a></li>-->
                <li class="menu-item menu-item-type-custom menu-item-object-custom "><a href="contact.php ">Contact</a></li>
                <li class="menu-item menu-item-type-custom menu-item-object-custom "><a href="logout.php ">Logout</a></li>

            </ul>
        </div>

        <div id="cssmenu2 " class="menu-one-page-menu-container ">
            <ul id="menu-one-page-menu-1 " class="menu ">

                <li class="menu-item menu-item-type-custom menu-item-object-custom "><a href="#home "><span>+91 9571538998</span></a></li>
                <li class="menu-item menu-item-type-custom menu-item-object-custom "><a href="#howitwork "><span>hello@peero.in</span></a></li>


            </ul>
        </div>
    </div>
    <div class="offcanvas-overly "></div>
    <!-- offcanvas-end -->

    <!-- main-area -->
    <main>

        <!-- search-popup -->
        <div class="modal fade bs-example-modal-lg search-bg popup1 " tabindex="-1 " role="dialog ">
            <div class="modal-dialog modal-lg " role="document ">
                <div class="modal-content search-popup ">
                    <div class="text-center ">
                        <a href="# " class="close2 " data-dismiss="modal " aria-label="Close ">× close</a>
                    </div>
                    <div class="row search-outer ">
                        <div class="col-md-11 "><input type="text " placeholder="Search for products... " /></div>
                        <div class="col-md-1 text-right "><a href="# "><i class="fa fa-search " aria-hidden="true "></i></a></div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /search-popup -->
        <!-- slider-area -->
        <section id="home " class="slider-area slider-four fix p-relative ">

            <div class="slider-active ">
                <div class="single-slider slider-bg d-flex align-items-center " style="background: url(img/slider/slider_img_bg.png) no-repeat;background-position: center center; ">
                    <div class="container ">
                        <div class="row justify-content-center pt-50 pb-150 ">
                            <div class="col-lg-7 ">
                                <div class="slider-content s-slider-content mt-200 ">

                                    <h2 data-animation="fadeInUp " data-delay=".4s "> Learn, Challenge, Connect!</h2>
                                    <p data-animation="fadeInUp " data-delay=".6s ">Crack the books with the most competitive and engaging online competitions.
                                    </p>

                                    <!-- <div class="subricbe " data-animation="fadeInDown " data-delay=".4s ">
                                        <form action="news-mail.php " method="post " class="contact-form ">
                                            <label><i class="icon fal fa-envelope "></i> Email Address</label>
                                            <input type="text " id="email2 " name="email2 " class="header-input " placeholder="Your Email Address... " required>
                                            <button class="btn header-btn "> Subscribe Now </button>
                                        </form> 
                                </div> -->

                                </div>
                            </div>
                            <div class="col-lg-5 ">
                                <div class="slider-img " data-animation="fadeInUp " data-delay=".4s ">
                                    <img src="img/slider/Group 4.png " alt="slider_img05 " style="height:600px ">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


            </div>


        </section>
        <!-- slider-area-end -->
        <!-- about-area -->
        <section id="about " class="about-area about-p pt-70 pb-120 p-relative " style="background: url(img/features/about-bg-aliments.png) no-repeat;background-position: center center; ">
            <div class="container ">
                <div class="row align-items-center ">
                    <div class="col-lg-6 col-md-12 col-sm-12 pr-30 ">
                        <div class="s-about-img p-relative wow fadeInLeft animated " data-animation="fadeInLeft " data-delay=".4s ">
                            <img src="img/features/Homepage1.png " alt="img ">
                            <!-- <div class="about-text second-about "> -->
                            <div class="all-text ">
                                <h3></h3>
                                <span> <br></span>
                            </div>

                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-sm-12 " style="float: right; ">
                        <div class="about-content s-about-content wow fadeInRight animated " data-animation="fadeInRight " data-delay=".4s ">
                            <div class="about-title second-atitle pb-25 ">
                                <h5>About</h5>
                                <h2>Welcome To Online Olympiads</h2>
                            </div>

                            <p>"Learn Continually, there’s always “one more thing to learn!"-Steve jobs</p>

                            <div class="about-content3 ">
                                <div class="row ">
                                    <div class="col-md-12 ">
                                        <ul class="green ">
                                            <li>Peer’O started with a vision of educating the children by taking the fun way of learning. Peer’O features an almost endless range of engaging and competitive competitions for the students to learn and also reward
                                                them for their accomplishments</li>
                                            <li>Peer’O offers unmatched service by developing/ offering customised, time-saving and effective learning material to crack the books. We spend our time connecting with the students around and having a lot of fun
                                                doing it.
                                            </li>
                                        </ul>
                                    </div>

                                </div>


                            </div>

                        </div>


                        <!-- <div class="slider-btn mt-10 ">
                            <a href="about.html " class="btn ss-btn " data-animation="fadeInRight " data-delay=".8s ">Read More</a>
                        </div> -->
                    </div>
                </div>

            </div>
            </div>
        </section>
        <!-- about-area-end -->
        <!-- vedio-area -->
        <!-- <section id="vedio " class="vedio-area pt-120 pb-90 fix " style=" background-image: url(img/video/vedio-bg.png); background-repeat: no-repeat; ">
            <div class="container ">
                <div class="row ">
                    <div class="col-lg-12 ">
                        <div class="section-title center-align text-center ">
                            <h5>Watch Us</h5>
                            <h2>
                                Start Growing With Community
                            </h2>
                        </div>

                    </div>

                </div>
                <div class="row ">
                    <div class="col-lg-12 col-md-12 ">

                        <div class="video-img wow fadeInRight animated " data-animation="fadeInDown animated " data-delay=".2s " style="background-image:url(img/video/vedio-img.png); background-repeat: no-repeat; background-position: center; ">
                            <a href="https://www.youtube.com/watch?v=gyGsPlt06bo " class="video-i popup-video "> <img src="img/video/play.svg " alt="img " class="active-icon "></a>
                        </div>


                    </div>


                </div>
            </div>
        </section> -->
        <!-- vedio-area-end -->

        <!-- services-area -->
        <section id="services " class="services-area pb-90 fix " style=" background-image: url(img/bg/services-bg-aliments.png); background-repeat: no-repeat; background-position: center; ">
            <div class="container ">

                <div class="row align-items-center ">
                    <div class="col-lg-4 col-md-12 ">
                        <div class="about-title second-atitle pb-20 ">
                            
                            <h2>
                                Why Participate?
                            </h2>
                            <!-- <p>Pellentesque fringilla, massa sit amet feugiat mollis, leo turpis elementum justo, vel consequat ex urna ut massa maecenas justo sapien.</p> -->
                        </div>

                        <!-- <div class="slider-btn mt-10 ">
                            <a href="courses.html " class="btn ss-btn " data-animation="fadeInRight " data-delay=".8s ">View All Services</a>
                        </div> -->
                    </div>
                    <div class="col-lg-8 col-md-12 ">
                        <div class="row ">
                            <div class="col-lg-4 col-md-6 ">
                                <div class="services-box wow fadeInDown animated " data-delay=".5s ">
                                    <div class="services-icon ">
                                        <img src="img/icon/pv-icon1.png " alt="icon01 ">
                                    </div>
                                    <div class="services-content2 ">
                                        <!-- <h5><a href="services-detail.html ">Skilled Lecturers</a> </h5> -->
                                        <p>We got covered all your schooling syllabus to make you at ease with the concepts.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 ">
                                <div class="services-box wow fadeInDown animated " data-delay=".5s ">
                                    <div class="services-icon ">
                                        <img src="img/icon/pv-icon2.png " alt="icon01 ">
                                    </div>
                                    <div class="services-content2 ">
                                        <!-- <h5><a href="services-detail.html ">Hot Stone Message</a> </h5> -->
                                        <p>Put in some extra preparation while competing with other students all over India.

                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 ">
                                <div class="services-box wow fadeInDown animated " data-delay=".5s ">
                                    <div class="services-icon ">
                                        <img src="img/icon/pv-icon3.png " alt="icon01 ">
                                    </div>
                                    <div class="services-content2 ">
                                        <!-- <h5><a href="services-detail.html ">Book Library</a> </h5> -->
                                        <p>Answer our subject-based questions and test your knowledge for quick, easy assessments.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 ">
                                <div class="services-box wow fadeInDown animated " data-delay=".5s ">
                                    <div class="services-icon ">
                                        <img src="img/icon/pv-icon4.png " alt="icon01 ">
                                    </div>
                                    <div class="services-content2 ">
                                        <!-- <h5><a href="services-detail.html ">Online Classes</a> </h5> -->
                                        <p>Effectively creative laid layouts with time limits help experience and explore that one extra mile.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 ">
                                <div class="services-box wow fadeInDown animated " data-delay=".5s ">
                                    <div class="services-icon ">
                                        <img src="img/icon/pv-icon5.png " alt="icon01 ">
                                    </div>
                                    <div class="services-content2 ">
                                        <!-- <h5><a href="services-detail.html ">Home Projects</a> </h5> -->
                                        <p>Get yourself an all India Rank and guaranteed recognition certificates with good rewards. </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 ">
                                <div class="services-box wow fadeInDown animated " data-delay=".5s ">
                                    <div class="services-icon ">
                                        <img src="img/icon/pv-icon6.png " alt="icon01 ">
                                    </div>
                                    <div class="services-content2 ">
                                        <!-- <h5><a href="services-detail.html ">24x7 Support</a> </h5> -->
                                        <p>Carve your path through to win some exciting prizes and exclusive merchandise.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>



                    </div>


                </div>
            </div>
        </section>
        <!-- services-area-end -->

        <!-- featured-courses-area -->
        <!-- <section id="courses " class="courses-area fix ">
            <div class="container-fluid ">
                <div class="row ">
                    <div class="col-lg-12 ">
                        <div class="section-title center-align text-center mb-50 ">
                            <h5>Best Courses</h5>
                            <h2>
                                Featured Courses
                            </h2>
                        </div>

                    </div>

                </div>
                <div class="row ">
                    <div class="col-lg-12 col-md-12 ">

                        <div class="featured-courses-active ">

                            <div class="box-courses ">
                                <a href="courses-details.html "><img src="img/featured-courses/courses-img1.png " alt="courses-img1 "></a>
                                <div class="text ">
                                    <h5>3 Years</h5>
                                    <h3><a href="courses-details.html ">Civil Engeering</a></h3>
                                </div>
                            </div>
                            <div class="box-courses ">
                                <a href="courses-details.html "> <img src="img/featured-courses/courses-img2.png " alt="courses-img1 "></a>
                                <div class="text ">
                                    <h5>3 Years</h5>
                                    <h3><a href="courses-details.html ">Civil Engeering</a></h3>
                                </div>
                            </div>
                            <div class="box-courses ">
                                <a href="courses-details.html "> <img src="img/featured-courses/courses-img3.png " alt="courses-img1 "></a>
                                <div class="text ">
                                    <h5>3 Years</h5>
                                    <h3><a href="courses-details.html ">Civil Engeering</a></h3>
                                </div>
                            </div>
                            <div class="box-courses ">
                                <a href="courses-details.html "> <img src="img/featured-courses/courses-img4.png " alt="courses-img1 "></a>
                                <div class="text ">
                                    <h5>3 Years</h5>
                                    <h3><a href="courses-details.html ">Civil Engeering</a></h3>
                                </div>
                            </div>
                            <div class="box-courses ">
                                <a href="courses-details.html "><img src="img/featured-courses/courses-img5.png " alt="courses-img1 "></a>
                                <div class="text ">
                                    <h5>3 Years</h5>
                                    <h3><a href="courses-details.html ">Civil Engeering</a></h3>
                                </div>
                            </div>
                            <div class="box-courses ">
                                <a href="courses-details.html "><img src="img/featured-courses/courses-img1.png " alt="courses-img1 "></a>
                                <div class="text ">
                                    <h5>3 Years</h5>
                                    <h3><a href="courses-details.html ">Civil Engeering</a></h3>
                                </div>
                            </div>

                        </div>


                    </div>


                </div>
            </div>
        </section> -->
        <!-- featured-courses-area-end -->
        <!-- eventes-area -->
        <section id="eventes " class="eventes-area fix pt-120 pb-120 " style=" background-image: url(img/bg/event-bg-aliments.png); background-repeat: no-repeat; background-position: center; ">
            <div class="container ">
                <div class="row ">
                    <div class="col-lg-12 ">
                        <div class="section-title center-align text-center mb-50 ">
                            <h5>Competitions</h5>
                            <h2>
                                Upcoming Competitions
                            </h2>
                        </div>

                    </div>

                </div>
                <div class="row ">
                    <div class="col-lg-6 col-md-12 ">

                        <div class="eventes-box ">
                            <div class="date-box ">
                                <h3>01</h3>

                                <h4>August, 2021</h4>
                            </div>
                            <div class="text ">
                                <h5><a href="english.php ">English-Quiz</a></h5>
                                <ul>
                                    <li><i class="fal fa-clock "></i>11:00Am-12:30Pm</li>
                                    <li><i class="icon fal fa-map-marker-check "></i> Online, India</li>
                                </ul>
                                <p>Polish up your English skills with our language competitions for students in a fun way. Find a wide range of multiple-choice questions, fill in the blanks and true or false questions from our knowledge bank.


                                </p>
                            </div>
                        </div>


                    </div>
                    <div class="col-lg-6 col-md-12 ">

                        <div class="eventes-box ">
                            <div class="date-box ">
                                <h3>01</h3>

                                <h4>August, 2021</h4>
                            </div>
                            <div class="text ">
                                <h5><a href="science.php">Science-Quiz</a></h5>
                                <ul>
                                    <li><i class="fal fa-clock "></i> 1:00Pm - 2:30Pm</li>
                                    <li><i class="icon fal fa-map-marker-check "></i> Online, India</li>
                                </ul>
                                <p>Scratch your heads by taking up our exam specific content ranging from chemistry, physics and biology. Find a wide range of multiple-choice questionnaires, fill in the blanks and true or false questions from our bank.
                                </p>
                            </div>
                        </div>


                    </div>
                    <!-- <div class="col-lg-6 col-md-12 ">

                        <div class="eventes-box ">
                            <div class="date-box ">
                                <h3>07</h3>
                                <h5>March, 2021</h5>
                            </div>
                            <div class="text ">
                                <h5><a href="events-details.html ">Cras faucibus ornare ipsum luctus.</a></h5>
                                <ul>
                                    <li><i class="fal fa-clock "></i> 9:00Am - 3:00Pm</li>
                                    <li><i class="icon fal fa-map-marker-check "></i> Mumbai, India</li>
                                </ul>
                                <p>Phasellus maximus orci metus. Nullam enim ex, facilisis at lacinia sed, luctus vitae dolor. Nam at commodo quam.</p>
                            </div>
                        </div>


                    </div>
                    <div class="col-lg-6 col-md-12 ">

                        <div class="eventes-box ">
                            <div class="date-box ">
                                <h3>17</h3>
                                <h5>Jan, 2021</h5>
                            </div>
                            <div class="text ">
                                <h5><a href="events-details.html ">Cras faucibus ornare ipsum luctus.</a></h5>
                                <ul>
                                    <li><i class="fal fa-clock "></i> 9:00Am - 3:00Pm</li>
                                    <li><i class="icon fal fa-map-marker-check "></i> Mumbai, India</li>
                                </ul>
                                <p>Phasellus maximus orci metus. Nullam enim ex, facilisis at lacinia sed, luctus vitae dolor. Nam at commodo quam.</p>
                            </div>
                        </div>


                    </div>
                    <div class="col-lg-6 col-md-12 ">

                        <div class="eventes-box ">
                            <div class="date-box ">
                                <h3>03</h3>
                                <h5>Jun, 2021</h5>
                            </div>
                            <div class="text ">
                                <h5><a href="events-details.html ">Cras faucibus ornare ipsum luctus.</a></h5>
                                <ul>
                                    <li><i class="fal fa-clock "></i> 9:00Am - 3:00Pm</li>
                                    <li><i class="icon fal fa-map-marker-check "></i> Mumbai, India</li>
                                </ul>
                                <p>Phasellus maximus orci metus. Nullam enim ex, facilisis at lacinia sed, luctus vitae dolor. Nam at commodo quam.</p>
                            </div>
                        </div>


                    </div>
                    <div class="col-lg-6 col-md-12 ">

                        <div class="eventes-box ">
                            <div class="date-box ">
                                <h3>28</h3>
                                <h5>Apr, 2021</h5>
                            </div>
                            <div class="text ">
                                <h5><a href="events-details.html ">Cras faucibus ornare ipsum luctus.</a></h5>
                                <ul>
                                    <li><i class="fal fa-clock "></i> 9:00Am - 3:00Pm</li>
                                    <li><i class="icon fal fa-map-marker-check "></i> Mumbai, India</li>
                                </ul>
                                <p>Phasellus maximus orci metus. Nullam enim ex, facilisis at lacinia sed, luctus vitae dolor. Nam at commodo quam.</p>
                            </div>
                        </div>


                    </div>


                </div>
                <div class="row text-center ">
                    <div class="col-lg-12 ">
                        <div class="slider-btn mt-30 ">
                            <a href="events.html " class="btn ss-btn " data-animation="fadeInRight " data-delay=".8s ">View All Services</a>
                        </div>
                    </div>
                </div>
            </div> -->
        </section>
        <!-- eventes-area-end -->
        <!-- testimonial-area -->
        <section class="testimonial-area pt-120 pb-120 " style=" background-image: url(img/testimonial/test-bg-aliments.png); background-repeat: no-repeat; background-position: center; background-color: #fff7f5; ">
            <div class="container ">
                <div class="row ">
                    <div class="col-lg-6 ">
                        <div class="about-title second-atitle pt-15 ">
                            <h5>Testimonial</h5>
                            <h2>
                                See What Our <br>Students Say’s
                            </h2>
                            <p class="pt-15 ">Our students send us a lot of cheers and we absolutely love them!
                            </p>
                        </div>

                    </div>

                    <div class="col-lg-6 ">
                        <div class="testimonial-active ">
                            <div class="single-testimonial ">
                                <div class="testi-author ">
                                    <!-- <img src="img/testimonial/testi_avatar.png " alt="img "> -->
                                    <div class="ta-info ">

                                        <h6>Sheetal Pandey</h6>
                                        <span>Student</span>

                                    </div>
                                </div>
                                <div class="qt-img ">
                                    <img src="img/testimonial/qt-icon.png " alt="img ">
                                </div>
                                <p> I love these competitions. It gives me a platform to apply theoretical concepts practically.

                                </p>

                            </div>
                            <div class="single-testimonial ">
                                <div class="testi-author ">
                                    <!-- <img src="img/testimonial/testi_avatar.png " alt="img "> -->
                                    <div class="ta-info ">
                                        <h6>Rohan Kumar</h6>
                                        <span>Student</span>
                                    </div>
                                </div>
                                <div class="qt-img ">
                                    <img src="img/testimonial/qt-icon.png " alt="img ">
                                </div>
                                <p>The achievements and awards give the motivation to compete. The competition certificates will help in the future.
                                </p>

                            </div>
                            <div class="single-testimonial ">
                                <div class="testi-author ">
                                    <!-- <img src="img/testimonial/testi_avatar.png " alt="img "> -->
                                    <div class="ta-info ">
                                        <h6>Maria Diaz</h6>
                                        <span>Student</span>
                                    </div>
                                </div>
                                <div class="qt-img ">
                                    <img src="img/testimonial/qt-icon.png " alt="img ">
                                </div>
                                <p>Time saver- It provides me with quick assessments and gives key insights for improvement.

                                </p>

                            </div>


                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- testimonial-area-end -->



        <!-- blog-area -->
        <!-- <section id="blog " class="blog-area p-relative pt-120 pb-90 fix " style=" background-image: url(img/bg/blog-bg-aliments.png); background-repeat: no-repeat; background-position: center; ">
            <div class="container ">
                <div class="row align-items-center ">
                    <div class="col-lg-12 ">
                        <div class="col-lg-12 ">
                            <div class="section-title center-align text-center mb-50 ">
                                <h5>Our Blog</h5>
                                <h2>
                                    Latest News Feed
                                </h2>
                            </div>

                        </div>


                    </div>
                </div>
                <div class="row ">
                    <div class="col-lg-4 col-md-12 ">
                        <div class="single-post2 mb-30 wow fadeInDown animated ">
                            <div class="blog-thumb2 ">
                                <a href="blog-details.html "><img src="img/blog/blog_img01.png " alt="img "></a>

                            </div>
                            <div class="blog-content2 text-center ">
                                <div class="b-meta ">
                                    <div class="row ">
                                        <div class="col-lg-12 col-md-12 ">
                                            <div class="date-b ">
                                                <i class="fal fa-calendar-alt "></i> 7 March, 2019
                                            </div>

                                        </div>

                                    </div>
                                </div>

                                <div class="row ">
                                    <div class="col-lg-12 ">
                                        <h4><a href="blog-details.html ">How do I Sell Affiliate Products to My Customers</a></h4>
                                        <div class="blog-btn "><a href="blog-details.html "><i class="fal fa-chevron-circle-right "></i> Read More</a></div>
                                    </div>
                                </div>
                            </div>


                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 ">
                        <div class="single-post2 mb-30 wow fadeInUp animated ">
                            <div class="blog-thumb2 ">
                                <a href="blog-details.html "><img src="img/blog/blog_img02.png " alt="img "></a>

                            </div>
                            <div class="blog-content2 text-center ">
                                <div class="b-meta ">
                                    <div class="row ">
                                        <div class="col-lg-12 col-md-12 ">
                                            <div class="date-b ">
                                                <i class="fal fa-calendar-alt "></i> 7 March, 2019
                                            </div>

                                        </div>

                                    </div>
                                </div>
                                <div class="row ">
                                    <div class="col-lg-12 ">
                                        <h4><a href="blog-details.html ">How do I Sell Affiliate Products to My Customers</a></h4>
                                        <div class="blog-btn "><a href="blog-details.html "><i class="fal fa-chevron-circle-right "></i> Read More</a></div>
                                    </div>
                                </div>




                            </div>


                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 ">
                        <div class="single-post2 mb-30 wow fadeInDown animated ">
                            <div class="blog-thumb2 ">
                                <a href="blog-details.html "><img src="img/blog/blog_img03.png " alt="img "></a>

                            </div>
                            <div class="blog-content2 text-center ">
                                <div class="b-meta ">
                                    <div class="row ">
                                        <div class="col-lg-12 col-md-12 ">
                                            <div class="date-b ">
                                                <i class="fal fa-calendar-alt "></i> 7 March, 2019
                                            </div>

                                        </div>

                                    </div>
                                </div>
                                <div class="row ">
                                    <div class="col-lg-12 ">
                                        <h4><a href="blog-details.html ">How do I Sell Affiliate Products to My Customers</a></h4>
                                        <div class="blog-btn "><a href="blog-details.html "><i class="fal fa-chevron-circle-right "></i> Read More</a></div>
                                    </div>
                                </div>



                            </div>


                        </div>
                    </div>

                </div>
            </div>
        </section> -->
        <!-- blog-area-end -->



    </main>
    <!-- main-area-end -->
    <!-- footer -->
    <footer class="footer-bg footer-p fix " style=" background-image: url(img/bg/footer-bg.png); background-repeat: no-repeat; background-position: center; ">
        <div class="footer-top pt-70 pb-40 ">
            <div class="container ">
                <div class="row ">
                    <div class="col-xl-3 col-lg-3 col-sm-12 ">
                        <div class="footer-widget mb-30 ">

                            <img src="img/logo/f_logo.png " alt="img ">

                        </div>
                    </div>
                    <div class="col-xl-7 col-lg-7 col-sm-12 ">
                        <div class="footer-widget footer-link mt-20 text-center ">
                            <ul>
                                <li><a href="index.php">Home</a></li>
                                <li><a href="about.php"> About Us</a></li>
                                <li><a href="competetion.php ">Olympiads</a></li>
                                <!-- <li><a href="services.html "> Courses </a></li>
                                <li><a href="contact.html "> Events</a></li>
                                <li><a href="blog.html ">Blog </a></li> -->
                                <li><a href="contact.php ">Contact Us </a></li>
                            </ul>


                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-2 col-sm-12 ">
                        <div class="footer-widget footer-social mt-15 text-right text-xl-right ">
                            <a href="https://www.facebook.com/PeerO.in/ "><i class="fab fa-facebook-f "></i></a>
                            <a href="https://www.instagram.com/peero.in/ "><i class="fab fa-instagram "></i></a>
                            <!-- <a href="# "><i class="fab fa-twitter "></i></a> -->

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-center pt-70 pb-40 ">
            <div class="container ">
                <div class="row justify-content-between ">

                    <div class="col-xl-3 col-lg-3 col-sm-6 ">
                        <div class="footer-widget mb-30 ">
                            <div class="f-widget-title ">
                                <h2>About Us</h2>
                            </div>
                            <div class="footer-link ">
                                Need something? Peer’O is here to help. For any queries please contact us on our details below </div>

                        </div>
                    </div>

                    <div class="col-xl-3 col-lg-3 col-sm-6 ">
                        <div class="footer-widget mb-30 ">
                            <div class="f-widget-title ">
                                <h2>Contact Us</h2>
                            </div>
                            <div class="f-contact ">
                                <ul>
                                    <li>
                                        <i class="icon fal fa-map-marker-check "></i>
                                        <span>No.9, 2nd Floor, Kaveri Mansion, HAL, Bangalore, 560017</span>
                                    </li>
                                    <li>
                                        <i class="icon fal fa-phone "></i>
                                        <span>+91 9571538998<br></span>
                                    </li>
                                    <li><i class="icon fal fa-envelope "></i>
                                        <span>
                                            <a href="mailto:info@example.com ">hello@peero.in</a>
                                       <br>
                                       <!-- <a href="mailto:help@example.com ">help@example.com</a> -->
                                       </span>
                                    </li>


                                </ul>

                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-sm-6 ">
                        <div class="footer-widget mb-30 ">
                            <div class="f-widget-title ">
                                <h2>Our Services</h2>
                            </div>
                            <div class="footer-link ">
                                <ul>
                                    <li><a href="index.php ">Home</a></li>
                                    <li><a href="about.php "> About Us</a></li>
                                    <li>
                                        <a href="competetion.php ">Olympiads</a
                                    ></li>
                                    <li><a href="contact.html "> Contact Us</a></li>
                                    <!-- <li><a href="blog.html ">Blog </a></li> -->
                                </ul>
                            </div>
                        </div>
                    </div>


                    <!-- <div class="col-xl-3 col-lg-3 col-sm-6 ">
                        <div class="footer-widget mb-30 ">
                            <div class="f-widget-title ">
                                <h2>Our Gallery</h2>
                            </div>
                            <div class="f-insta ">
                                <ul>
                                    <li>
                                        <a href="img/instagram/f-galler-01.png " class=" popup-image "><img src="img/instagram/f-galler-01.png " alt="img "></a>
                                    </li>
                                    <li>
                                        <a href="img/instagram/f-galler-02.png " class=" popup-image "><img src="img/instagram/f-galler-02.png " alt="img "></a>
                                    </li>
                                    <li>
                                        <a href="img/instagram/f-galler-03.png " class=" popup-image "><img src="img/instagram/f-galler-03.png " alt="img "></a>
                                    </li>
                                    <li>
                                        <a href="img/instagram/f-galler-04.png " class=" popup-image "><img src="img/instagram/f-galler-04.png " alt="img "></a>
                                    </li>

                                </ul>
                            </div>
                        </div>
                    </div> -->

                </div>
            </div>
        </div>
        <div class="copyright-wrap ">
            <div class="container ">
                <div class="row align-items-center ">
                    <div class="col-lg-6 ">
                        Copyright &copy; 2021 Peero. All rights reserved.
                    </div>
                    <div class="col-lg-6 text-right text-xl-right ">
                        <ul>
                        <li><a href="# ">Privacy</a></li>
                            <li><a href="# ">Term & Conditions</a></li>
                            <li><a href="# ">Legal</a></li>
                        </ul>
                    </div>

                </div>
            </div>
        </div>
    </footer>
    <!-- footer-end -->


    <!-- JS here -->
    <script src="js/vendor/modernizr-3.5.0.min.js "></script>
    <script src="js/vendor/jquery-1.12.4.min.js "></script>
    <script src="js/popper.min.js "></script>
    <script src="js/bootstrap.min.js "></script>
    <script src="js/one-page-nav-min.js "></script>
    <script src="js/slick.min.js "></script>
    <script src="js/ajax-form.js "></script>
    <script src="js/paroller.js "></script>
    <script src="js/wow.min.js "></script>
    <script src="js/js_isotope.pkgd.min.js "></script>
    <script src="js/imagesloaded.min.js "></script>
    <script src="js/parallax.min.js "></script>
    <script src="js/jquery.waypoints.min.js "></script>
    <script src="js/jquery.counterup.min.js "></script>
    <script src="js/jquery.scrollUp.min.js "></script>
    <script src="js/jquery.meanmenu.min.js "></script>
    <script src="js/parallax-scroll.js "></script>
    <script src="js/jquery.magnific-popup.min.js "></script>
    <script src="js/element-in-view.js "></script>
    <script src="js/main.js "></script>
</body>

</html>