<?php
  session_start();

//   if (isset($_SESSION['id'])) {
//   header("Location:welcome.php");
//   }

  // Include database connectivity
    
  include_once('config.php');
  
  if (isset($_POST['but_submit'])) {
    
    
      $errorMsg = "";
      
      $email    = mysqli_real_escape_string($conn, $_POST['email']);
      $password = mysqli_real_escape_string($conn, $_POST['password']); 
      
  if (!empty($email) || !empty($password)) {
        $query  = "SELECT * FROM users WHERE email = '$email'";
        $result = mysqli_query($conn, $query);
        if(mysqli_num_rows($result) == 1){
          while ($row = mysqli_fetch_assoc($result)) {
            if (password_verify($password, $row['password'])) {
                $_SESSION['id'] = $row['id'];
                $_SESSION['username'] = $row['username'];
                header("Location:index.php");
            }else{
               echo "<script
               type='text/jscript'>alert('Email or Password is invalid!')
               window.location.href='Login.html';
               </script>";
            }    
          }
        }else{
          echo  "<script
          type='text/jscript'>alert('Please Register!No User With These Credentials.')
          window.location.href='Login.html';
          </script>";
        } 
    }else{
      echo "<script
      type='text/jscript'>alert('Email and Password is required')
      window.location.href='Login.html';
      </script>";
    }
  }
  // Check the correct login (for example with a database)


?>