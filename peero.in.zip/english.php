<?php

$showAlert = false; 
$showSuccess = false; 

session_start(); 
include_once 'config.php';
if(isset($_POST['button1'])){
    $que  = "SELECT * FROM users WHERE id = '".$_SESSION["id"]."'";
    $result = mysqli_query($conn, $que);
        if(mysqli_num_rows($result) == 1){
          while ($row = mysqli_fetch_assoc($result)){
              if($row['english']==Null){
    $query = "UPDATE users SET english ='1'  WHERE id = '".$_SESSION["id"]."'";
    $upd=mysqli_query($conn, $query) or die(mysqli_error($mysqli));
$showSuccess=true;}else{$showAlert=true;}              

}
//     if($query){echo'success';}
// else{echo'error';}
}}
// $query  = "SELECT * FROM users WHERE id = '".$_SESSION["id"]."'";
//        echo("$query");  $result = mysqli_query($conn, $query);
//         if(mysqli_num_rows($result) == 1){
//           while ($row = mysqli_fetch_assoc($result)) {
//             //   
//           }  }else{echo'bhakk';}
 //Yes, i do realize that i need a WHERE to avoid updating the whole     table.


//  include_once 'config.php';
// session_start();
// // $email=$_SESSION['email'];

//   if(!(isset($_SESSION['submit']))){
//     echo '<br />';
//     $id=@$_GET['fid'];
//     $result = mysqli_query($conn,"SELECT * FROM users WHERE id='$id' ") or die('Error');
//     while($row = mysqli_fetch_array($result)) {
//         $_SESSION['id'] = $fetch['id'];
//         $query = mysqli_query($conn,"UPDATE users SET english = '1' WHERE id = {$_SESSION['id']};");
//   }

//   }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>English-Quiz</title>
    <link rel="shortcut icon" type="image/x-icon" href="img/favicon.ico">
    <!-- Place favicon.ico in the root directory -->

    <!-- CSS here -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="fontawesome/css/all.min.css">
    <link rel="stylesheet" href="font-flaticon/flaticon.css">
    <link rel="stylesheet" href="css/dripicons.css">
    <link rel="stylesheet" href="css/slick.css">
    <link rel="stylesheet" href="css/meanmenu.css">
    <link rel="stylesheet" href="css/default.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window,document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '178286547560625'); 
fbq('track', 'PageView');
</script>
<noscript>
<img height="1" width="1" 
src="https://www.facebook.com/tr?id=178286547560625&ev=PageView
&noscript=1"/>
</noscript>
<!-- End Facebook Pixel Code -->

    <style>
        .counter {
            text-align: center;
            font-family: sans-serif;
            font-weight: 100;
            place-content: center;
        }
        
        h1 {
            font-weight: 100;
            font-size: 40px;
        }
        
        #clockdiv {
            font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;
            color: #fe8366;
            display:flex;
            font-weight: bolder;
            text-align: center;
            font-size: 20px;
             justify-content: center;
        }
        }
        
        #clockdiv>div {
            padding: 10px;
            border-radius: 3px;
            display: inline-block;
        }
        
        #clockdiv div>span {
            padding: 15px;
            border-radius: 3px;
            display: inline-block;
        }
        
        .smalltext {
          margin:5px;
        }
    </style>
</head>


<body>
    <!-- header -->
    <header class="header-area header-three">
        <div id="header-sticky" class="menu-area">
            <div class="container">
                <div class="second-menu">
                    <div class="row align-items-center">
                        <div class="col-xl-2 col-lg-2">
                            <div class="logo">
                                <a href="index.php"><img src="img/logo/logo.png" alt="logo"></a>
                            </div>
                        </div>
                        <div class="col-xl-8 col-lg-8">

                            <div class="main-menu text-right text-xl-right">
                                <nav id="mobile-menu" style="display: block;">
                                    <ul>
                                        <li class="sub">
                                            <a href="index.php">Home</a>
                                        </li>
                                        <li><a href="about.php">About Us</a></li>
                                        <li class="sub">
                                            <a href="competetion.php">Olympiads</a>
                                            <ul>

                                                <li>
                                                    <a href="science.php">Science</a>
                                                </li>
                                            </ul>
                                        </li>
                                       
                                        <!-- <li class="sub">
                                        <a href="events.html">Events</a>
                                        <ul>
                                            <li><a href="events.html">Events</a></li>
                                            <li><a href="events-details.html">Events Details</a></li>
                                        </ul>
                                    </li>

                                    <li class="sub"><a href="#">Pages</a>
                                        <ul>
                                            <li><a href="projects.html">Gallery</a></li>
                                            <li><a href="projects-detail.html">Gallery Details</a></li>

                                            <li><a href="pricing.html">Pricing</a></li>
                                            <li><a href="team.html">Team</a></li>
                                            <li><a href="faq.html">Faq</a></li>
                                            <li><a href="shop.html">Shop</a></li>
                                            <li><a href="shop-details.html">Shop Details</a>
                                            </li>
                                        </ul>
                                    </li>

                                    <li class="sub">
                                        <a href="#">News</a>
                                        <ul>
                                            <li><a href="#">News</a></li>
                                            <li><a href="#">News Details</a></li>
                                        </ul>
                                    </li> -->


                                        <li><a href="contact.php">Contact</a></li>
                                         <li> <a href="logout.php">Logout</a></li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        <div class="col-xl-2 col-lg-2 text-right d-none d-xl-block mt-30 mb-30">
                            <div class="search-top2">
                                <ul>

                                    <li>
                                        <a href="#" class="menu-tigger"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" class="menu-tigger"><img src="img/icon/menu.png" alt="logo"></a>
                                    </li>
                                </ul>
                            </div>
                        </div>


                        <div class="col-12">
                            <div class="mobile-menu"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- header-end -->
    <!-- offcanvas-area -->
    <div class="offcanvas-menu">
        <span class="menu-close"><i class="fas fa-times"></i></span>
        <form role="search" method="get" id="searchform" class="searchform" action="http://wordpress.zcube.in/xconsulta/">
            <input type="text" name="s" id="search" value="" placeholder="Search" />
            <button><i class="fa fa-search"></i></button>
        </form>


        <div id="cssmenu3" class="menu-one-page-menu-container">
            <ul id="menu-one-page-menu-2" class="menu">               
                 <li class="menu-item menu-item-type-custom menu-item-object-custom"><a href="competetion.php"><span>Olympiads</span></a></li>

                <li class="menu-item menu-item-type-custom menu-item-object-custom"><a href="index.php">Home</a></li>
                <li class="menu-item menu-item-type-custom menu-item-object-custom"><a href="about.php">About Us</a></li>
                <!-- <li class="menu-item menu-item-type-custom menu-item-object-custom"><a href="services.html">Services</a></li>
            <li class="menu-item menu-item-type-custom menu-item-object-custom"><a href="pricing.html">Pricing </a></li>
            <li class="menu-item menu-item-type-custom menu-item-object-custom"><a href="team.html">Team </a></li>

            <li class="menu-item menu-item-type-custom menu-item-object-custom"><a href="projects.html">Gallery Study</a></li>
            <li class="menu-item menu-item-type-custom menu-item-object-custom"> <a href="#">Quizes</a></li>-->
                <li class="menu-item menu-item-type-custom menu-item-object-custom"><a href="contact.php">Contact</a></li>
            </ul>
        </div>

        <div id="cssmenu2" class="menu-one-page-menu-container">
            <ul id="menu-one-page-menu-1" class="menu">
                <li class="menu-item menu-item-type-custom menu-item-object-custom">
                    <a href="logout.php">Logout</a></li>
                <li class="menu-item menu-item-type-custom menu-item-object-custom"><a href="#home"><span>+91 9571538998 </span></a></li>
                <li class="menu-item menu-item-type-custom menu-item-object-custom"><a href="#howitwork"><span>hello@peero.in</span></a></li>


            </ul>
        </div>
    </div>
    <div class="offcanvas-overly"></div>
    <!-- offcanvas-end -->
    <main>

        <!-- search-popup -->
        <div class="modal fade bs-example-modal-lg search-bg popup1" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content search-popup">
                    <div class="text-center">
                        <a href="#" class="close2" data-dismiss="modal" aria-label="Close">× close</a>
                    </div>
                    <div class="row search-outer">
                        <div class="col-md-11"><input type="text" placeholder="Search for products..." /></div>
                        <div class="col-md-1 text-right"><a href="#"><i class="fa fa-search" aria-hidden="true"></i></a></div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /search-popup -->
        <!-- /search-popup -->
        <!-- breadcrumb-area -->
        <section class="breadcrumb-area d-flex align-items-center" style="background-image:url(img/testimonial/test-bg.png)">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-xl-12 col-lg-12">
                        <div class="breadcrumb-wrap text-left">
                            <div class="breadcrumb-title">
                                <h2>ENGLISH</h2>
                                <div class="breadcrumb-wrap">

                                    <nav aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                            <!-- <li class="breadcrumb-item active" aria-current="page">Pricing</li> -->
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>
        <!-- breadcrumb-area-end -->
        <!-- Project Detail -->
        <section class="project-detail">
            <div class="container">
                <!-- Lower Content -->
                <div class="lower-content">
                    <div class="row">
                        <div class="text-column col-lg-8 col-md-8 col-sm-12">
                            <h2>English Olympiad</h2>
                            <ul class="course-meta review style2 clearfix mb-30">
                                <li class="author">
                                    <!-- <div class="thumb">
                                        <img src="img/testimonial/testi_avatar.png" alt="image">
                                    </div> -->

                                    <!-- <div class="text">
                                        <a href="#">Roshanpriya Harman</a>
                                        <p>Invigilator</p>
                                    </div>
                                </li>
                                <li class="categories">
                                    <a href="#" class="course-name">Exam/Quiz</a>
                                    <p>Categories</p>
                                </li>
                                <li class="categories">
                                    <a href="#" class="course-name">Price</a>
                                    <p>$59.00</p>
                                </li> -->

                            </ul>
                            <div class="upper-box">
                                <div class="single-item-carousel owl-carousel owl-theme">
                                    <figure class="image"><img src="img/gallery/English Page.png" alt=""></figure>
                                </div>
                            </div>
                            <div class="inner-column">

                                <p><span class="dropcap">E</span> English is one of the most influential languages in the world and is the most commonly spoken language with almost 53 countries classifying it as their official language.
                                </p>
                                <p> We here at Peer’O are applying sophisticated research and development to provide standardised English competitions for our students from classes 6 to 12. It can further your career, help you find a good job, or improve
                                    your skills for academic excellence. Its growing popularity makes it an essential skill for new opportunities worldwide.
                                </p>
                                <p> By taking these competitions you are testing your knowledge and it can help assess your strengths and weaknesses.
                                </p>

                                <!-- <p>The world of search engine optimization is complex and ever-changing, but you can easily <strong>understand the basics</strong>, and even a small amount of SEO knowledge can make a big difference. <strong>Free SEO education</strong>                                    is also widely available on the web, including in guides like this! (Woohoo!) This guide is designed to describe all major aspects of SEO, from finding the terms and phrases (keywords) that can generate qualified traffic
                                    to your website, to making your site friendly to search engines, to building links and marketing the unique value of your site.</p>
                                <h4>Study Options:</h4> -->
                                <!-- <table class="table table-bordered mb-30">
                                    <thead>
                                        <tr>
                                            <th>Qualification</th>
                                            <th>Length</th>
                                            <th>Code</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Bsc (Hons)</td>
                                            <td>3 years full time</td>
                                            <td>CDX3</td>
                                        </tr>
                                        <tr>
                                            <td>Bsc </td>
                                            <td>4 years full time</td>
                                            <td>CDX4</td>
                                        </tr>
                                    </tbody>
                                </table> -->
  <strong><h4 style="font-weight: bolder;">What are the prizes?</h4></strong>
                                    <div class="single-item-carousel owl-carousel owl-theme">
                                        <figure class="image"><img src="img/gallery/prize.png" alt=""></figure>
                                    </div>
                                <h4>FAQ's</h4>
                                <p>

                                </p>
                                <p> <strong> What is Peer’O ?</strong>
                                    <br> Peer’O serves to be an online education platform where students across the country challenge, compete and learn through online courses and competitions. It helps develop the overall ability of the students by letting
                                    them challenge their potential and also reward them for their efforts. These types of activities allow the students to break away from the typical schooling structure and help them learn while having fun!
                                    <br> <strong> How to participate in these competitions? </strong>
                                    <br> To participate in Peer’O competitions, students have to register themselves and fill in the required details. Visit the site regularly to be a part of the daily questionnaire program. These competitions are available
                                    for classes 6 to 12. All these courses and competitions offer chapter-wise and in detail questionnaires. It develops the overall skill-set of the participants.
                                    <br> <strong> How do I win?</strong><br> To win rewards and prizes you need to win the competitions on offer. Students need to develop and start in-depth thinking to solve various questions. Peer’O rewards participants
                                    with a guaranteed certification and also gives winners cash prizes and exclusive merchandise. It becomes easier to win when students practice with hard work and dedication.
                                    <br><strong> What will be the syllabus?</strong><br> The syllabus will fully be school-based content. Miscellaneous questions apart from in general syllabus will be an additional feature.<br><strong> Is Peer’O hard to attempt?</strong><br> 
                                    No, these competitions depend on the student’s practice. It becomes easier and creates interest in all participants as the competition focuses on application questions. The syllabus is the same as recommended by schools.
                                    <br>
                                   
                                    <br>
                                  


                                </p>
                                <br>
                            </div>


                            <p>
                                <h4>ONLINE EXAMS TEST TAKER GUIDE</h4>
                                <ol>
                                    <li>

                                        <p>Platform test will be proctored
                                        </p>
                                    </li>
                                    <li>
                                        <p>Platform requires a minimum upload bandwidth (speed) to run online tests for webcam proctored test at 512 kbps, can be checked at www.speedtest.net

                                        </p>
                                    </li>
                                    <li>
                                        <p>You can attempt tests on any of the alongside recommended browsers Browser For (Proctored test) Chrome version 86 and above Firefox version 68 and above

                                        </p>
                                    </li>
                                    <li>
                                        <p>Use the “allow once/always” pop-ups function from your browser settings to allow the test window to open
                                        </p>
                                    </li>
                                    <li>
                                        <p>Optionally, you may disable the pop-up blocker for the duration of the test. Here is how you can do it:

                                        </p>
                                    </li>
                                    <li>
                                        <p>Google Chrome: Go to ‘chrome://settings/’ --> Click on 'Show advanced settings'(at the end of the page). Under 'Privacy', click on 'Content Settings' --> Under 'Pop-ups', select ‘Allow all sites to show pop-ups’
                                            --> Click on Done.
                                        </p>
                                    </li>
                                    <li>
                                        <p>For Mozilla Firefox on Windows: Go to ‘Tools’ --> Select ‘Options’ --> Click ‘Content’ tab and then uncheck ‘Block Pop-up windows’ check box.

                                        </p>
                                    </li>
                                    <li>
                                        <p>You can access/launch the test using the Play Button in the link </p>
                                    </li>
                                </ol>

                            </p>
                        </div>
                        <div class="col-lg-4">
                            <aside class="sidebar-widget">
                                <section class="widget widget_search">
                                    <div class="course-widget-price">
                                        <h2 class="widget-title">Competition Features</h2>
                                        <ul>
                                            <li>
                                                <i class="fal fa-clock"></i>
                                                <span>Starts</span>
                                                <span class="time">Aug 1,2021</span>
                                            </li>
                                            <li>
                                                <i class="fal fa-exclamation-circle"></i>
                                                <span>Duration</span>
                                                <span class="time">1.5  Hours</span>
                                            </li>
<li>
                                                <i class="fal fa-times"></i>
                                                <span>Time</span>
                                                <span class="time">11:00Am-12:30Pm</span>
                                            </li>

                                            <!-- <li>
                                                <i class="fal fa-user-graduate "></i>
                                                <span>Institution</span>
                                                <span class="time ">Shivaji School</span>
                                            </li> -->

                                            <li>
                                                <i class="fal fa-user "></i>
                                                <span>Classes</span>
                                                <span class="time ">6th-12th</span>
                                            </li><li>
                                                <i class="fal fa-user "></i>
                                                <span>Total Prizes</span>
                                                <span class="time ">10000/-</span>
                                            </li>
                                             <li>
                                                <i class="fal fa-plus-hexagon "></i>
                                                <span class="pt-20 pb-20" style="font-weight:bolder">Total Students Registered</span>
                                                <span style=" color:red ">165</span>
                                            </li>
                                        </ul>
                                        <h5 class="pt-20 pb-20 ">Competetion Fee: <span style="color:red"><a style="color:black;;text-decoration:line-through;">Rs.100</a><strong>&nbsp;FREE</strong></span></h5>
                                      <form method="POST">  <a id="hnm"><button class="btn ss-btn " onclick="picture()"input-type="submit" id="btn" 
                                      name="button1">Register</button></a>
                                      </form>
<br>
<?php
        
        if($showAlert) {
    
            echo '
            <div class="alert alert-success 
                alert-dismissible fade show" role="alert">
        
                <strong>Already Registered For the competition!</strong> 
               

                <button type="button" class="close"
                    data-dismiss="alert" aria-label="Close"> 
                    <span aria-hidden="true">×</span> 
                </button> 
            </div> '; 
        }
        if($showSuccess) {
    
            echo '
            <div class="alert alert-success 
                alert-dismissible fade show" role="alert">
        
                <strong>Congratulations Successfuly Registered !</strong> 
                <span style="height:60px;width:70px;margin-left:20px"><img src="img/gallery/registration image.png" ></span>

                <button type="button" class="close"
                    data-dismiss="alert" aria-label="Close"> 
                    <span aria-hidden="true">×</span> 
                </button> 
            </div> '; 
        }
        
        
        
        
        ?>
                                        <!--<img style="display:none;" id="bigpic" src="bigpic" />-->
                                        <hr>
<!--                                        <script>function picture() {-->
<!--  const sourceOfPicture = "img/gallery/registration image.png";-->
<!--  const img = document.getElementById('bigpic')-->
<!--  img.src = sourceOfPicture.replace('90x90', '225x225');-->
<!--  img.style.display = "block";-->
<!--  document.getElementById("btn").innerHTML = "<center>Registered</center>"; -->
  
<!--} </script>-->
                                        <br>
                                        <div class="counter">
                                            <h1>
                                                <div style="height:100px;width:100px">
                                                    <ul>
                                                        <li>
                                                            <a><img src="img/logo/ct1.png" alt="logo" style="margin-left:90px;"></a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </h1>
                                            <br>
                                            <div id="clockdiv">
                                                <div>

                                                    <span class="days" id="day"></span>
                                                    <div class="smalltext">Days</div>

                                                </div>

                                                <div>
                                                    <span class="hours" id="hour"></span>
                                                    <div class="smalltext">Hours</div>
                                                </div>
                                                <div>
                                                    <span class="minutes" id="minute"></span>
                                                    <div class="smalltext">Minutes</div>
                                                </div>
                                                <div>
                                                    <span class="seconds" id="second"></span>
                                                    <div class="smalltext">Seconds</div>
                                                </div>

                                            </div>
                                            <!-- <div id="demo1 "> <a class="btn ss-btn " href="#" ;>Play On Time </a></div><br> -->
                                            <p id="demo"><a class="btn ss-btn " href="#" id="demo1" style="width:100%">Play On Time </a></p>
                                        </div>
                                        <script>
                                            var deadline = new Date("aug 1, 2021 11:00:00").getTime();

                                            var x = setInterval(function() {

                                                var now = new Date().getTime();
                                                var t = deadline - now;
                                                var days = Math.floor(t / (1000 * 60 * 60 * 24));
                                                var hours = Math.floor((t % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                                                var minutes = Math.floor((t % (1000 * 60 * 60)) / (1000 * 60));
                                                var seconds = Math.floor((t % (1000 * 60)) / 1000);
                                                document.getElementById("day").innerHTML = days;
                                                document.getElementById("hour").innerHTML = hours;
                                                document.getElementById("minute").innerHTML = minutes;
                                                document.getElementById("second").innerHTML = seconds;
                                                if (t < 0) {
                                                    clearInterval(x);

                                                    document.getElementById("demo1").innerHTML = "Play Now";
                                                    document.getElementById("demo1").href = "http://peero.in/quiz.html";
                                                    document.getElementById("demo1").target = "_blank";
                                                    document.getElementById("day").innerHTML = '0';
                                                    document.getElementById("hour").innerHTML = '0';
                                                    document.getElementById("minute").innerHTML = '0';
                                                    document.getElementById("second").innerHTML = '0';
                                                }
                                            }, 1000);
                                        </script>


                                    </div>
                        </div>


                    </div>

                    </section>

                    <!-- <div class="col-lg-4 "> -->





                    </aside>
                </div>






                <!--End Project Detail -->

    </main>
    <footer class="footer-bg footer-p fix " style=" background-image: url(img/bg/footer-bg.png); background-repeat: no-repeat; background-position: center; ">
        <div class="footer-top pt-70 pb-40 ">
            <div class="container ">
                <div class="row ">
                    <div class="col-xl-3 col-lg-3 col-sm-12 ">
                        <div class="footer-widget mb-30 ">

                            <img src="img/logo/f_logo.png " alt="img ">

                        </div>
                    </div>
                    <div class="col-xl-7 col-lg-7 col-sm-12 ">
                        <div class="footer-widget footer-link mt-20 text-center ">
                            <ul>
                                <li><a href="index.php ">Home</a></li>
                                <li><a href="about.php "> About Us</a></li>
                                <!-- <li><a href="services.html "> Courses </a></li>
                                <li><a href="contact.html "> Events</a></li>
                                <li><a href="blog.html ">Blog </a></li> -->
                                <li><a href="contact.php">Contact Us </a></li>
                            </ul>


                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-2 col-sm-12 ">
                        <div class="footer-widget footer-social mt-15 text-right text-xl-right ">
                            <a href="https://www.facebook.com/PeerO.in/ "><i class="fab fa-facebook-f "></i></a>
                            <a href="https://www.instagram.com/peero.in/"><i class="fab fa-instagram "></i></a>
                            <!-- <a href="# "><i class="fab fa-twitter "></i></a> -->

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-center pt-70 pb-40 ">
            <div class="container ">
                <div class="row justify-content-between ">

                    <div class="col-xl-3 col-lg-3 col-sm-6 ">
                        <div class="footer-widget mb-30 ">
                            <div class="f-widget-title ">
                                <h2>About Us</h2>
                            </div>
                            <div class="footer-link ">
                                Need something? Peer’O is here to help. For any queries please contact us on our details below </div>

                        </div>
                    </div>

                    <div class="col-xl-3 col-lg-3 col-sm-6 ">
                        <div class="footer-widget mb-30 ">
                            <div class="f-widget-title ">
                                <h2>Contact Us</h2>
                            </div>
                            <div class="f-contact ">
                                <ul>
                                   <li>
                                        <i class="icon fal fa-map-marker-check "></i>
                                        <span>No.9, Kaveri Mansion,HAL Bangalore,560017</span>
                                    </li>
                                    <li>
                                        <i class="icon fal fa-phone "></i>
                                        <span>+91-9571538998</span>
                                    </li>
                                    <li><i class="icon fal fa-envelope "></i>
                                        <span>
                                            <a href="mailto:info@example.com ">hello@peero.in</a>
                                       <br>
                                       <!--<a href="mailto:help@example.com ">help@example.com</a>-->
                                       </span>
                                    </li>


                                </ul>

                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-sm-6 ">
                        <div class="footer-widget mb-30 ">
                            <div class="f-widget-title ">
                                <h2>Our Services</h2>
                            </div>
                            <div class="footer-link ">
                                <ul>
                                    <li><a href="index.php ">Home</a></li>
                                    <li><a href="about.php "> About Us</a></li>
                                    <li>
                                        <a href="competetions.php ">Olympiads</a
                                    ></li>
                                    <li><a href="contact.php "> Contact Us</a></li>
                                    <!-- <li><a href="blog.html ">Blog </a></li> -->
                                </ul>
                            </div>
                        </div>
                    </div>


                    <!-- <div class="col-xl-3 col-lg-3 col-sm-6 ">
                        <div class="footer-widget mb-30 ">
                            <div class="f-widget-title ">
                                <h2>Our Gallery</h2>
                            </div>
                            <div class="f-insta ">
                                <ul>
                                    <li>
                                        <a href="img/instagram/f-galler-01.png " class=" popup-image "><img src="img/instagram/f-galler-01.png " alt="img "></a>
                                    </li>
                                    <li>
                                        <a href="img/instagram/f-galler-02.png " class=" popup-image "><img src="img/instagram/f-galler-02.png " alt="img "></a>
                                    </li>
                                    <li>
                                        <a href="img/instagram/f-galler-03.png " class=" popup-image "><img src="img/instagram/f-galler-03.png " alt="img "></a>
                                    </li>
                                    <li>
                                        <a href="img/instagram/f-galler-04.png " class=" popup-image "><img src="img/instagram/f-galler-04.png " alt="img "></a>
                                    </li>

                                </ul>
                            </div>
                        </div>
                    </div> -->

                </div>
            </div>
        </div>
        <div class="copyright-wrap ">
            <div class="container ">
                <div class="row align-items-center ">
                    <div class="col-lg-6 ">
                        Copyright &copy; 2021 Peero. All rights reserved.
                    </div>
                    <div class="col-lg-6 text-right text-xl-right ">
                        <ul>
                            <li><a href="# ">Privacy</a></li>
                            <li><a href="# ">Term & Conditions</a></li>
                            <li><a href="# ">Legal</a></li>
                        </ul>
                    </div>

                </div>
            </div>
        </div>
    </footer>
    <!-- footer-end -->


    <!-- JS here -->
    <script src="js/vendor/modernizr-3.5.0.min.js "></script>
    <script src="js/vendor/jquery-1.12.4.min.js "></script>
    <script src="js/popper.min.js "></script>
    <script src="js/bootstrap.min.js "></script>
    <script src="js/one-page-nav-min.js "></script>
    <script src="js/slick.min.js "></script>
    <script src="js/ajax-form.js "></script>
    <script src="js/paroller.js "></script>
    <script src="js/wow.min.js "></script>
    <script src="js/js_isotope.pkgd.min.js "></script>
    <script src="js/imagesloaded.min.js "></script>
    <script src="js/parallax.min.js "></script>
    <script src="js/jquery.waypoints.min.js "></script>
    <script src="js/jquery.counterup.min.js "></script>
    <script src="js/jquery.scrollUp.min.js "></script>
    <script src="js/jquery.meanmenu.min.js "></script>
    <script src="js/parallax-scroll.js "></script>
    <script src="js/jquery.magnific-popup.min.js "></script>
    <script src="js/element-in-view.js "></script>
    <script src="js/main.js "></script>
</body>

</html>

</html>ript src="js/jquery.magnific-popup.min.js "></script>
<script src="js/element-in-view.js "></script>
<script src="js/main.js "></script>
</body>

</html>

</html>