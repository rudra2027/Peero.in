<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Peero-Education</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/x-icon" href="img/favicon.ico">
    <!-- Place favicon.ico in the root directory -->

    <!-- CSS here -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="fontawesome/css/all.min.css">
    <link rel="stylesheet" href="font-flaticon/flaticon.css">
    <link rel="stylesheet" href="css/dripicons.css">
    <link rel="stylesheet" href="css/slick.css">
    <link rel="stylesheet" href="css/meanmenu.css">
    <link rel="stylesheet" href="css/default.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window,document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '178286547560625'); 
fbq('track', 'PageView');
</script>
<noscript>
<img height="1" width="1" 
src="https://www.facebook.com/tr?id=178286547560625&ev=PageView
&noscript=1"/>
</noscript>
<!-- End Facebook Pixel Code -->

</head>

<body>
    <!-- header -->
    <header class="header-area header-three">
        <div id="header-sticky" class="menu-area">
            <div class="container">
                <div class="second-menu">
                    <div class="row align-items-center">
                        <div class="col-xl-2 col-lg-2">
                            <div class="logo">
                                <a href="index.php"><img src="img/logo/logo.png" alt="logo"></a>
                            </div>
                        </div>
                        <div class="col-xl-8 col-lg-8">

                            <div class="main-menu text-right text-xl-right">
                                <nav id="mobile-menu" style="display: block;">
                                    <ul>
                                    <li class="sub">
                                            <a href="index.php">Home</a>
                                        </li>
                                        <li class="sub"><a href="about.php">About Us</a></li>
                                        <li class="sub">
                                            <a href="competetion.php">Olympiads</a>
                                            <ul>
                                                <li>
                                                    <a href="english.php ">English</a>
                                                </li>
                                                <li>
                                                    <a href="science.php ">Science</a>
                                                </li>
</ul>
                                        <li><a href="contact.php">Contact</a></li> 
                                        <li> <a href="logout.php">Logout</a></li> <li class="sub ">
                                        <!-- <li class="nav-item active"> -->
       
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        <div class="col-xl-2 col-lg-2 text-right d-none d-xl-block mt-30 mb-30">
                            <div class="search-top2">
                                <ul>

                                    <li><a href="#" class="menu-tigger"><i class="fas fa-search"style="display:none"></i></a></li>
                                    <li>
                                        <a href="#" class="menu-tigger"><img src="img/icon/menu.png" alt="logo"></a>
                                    </li>
                                </ul>
                            </div>
                        </div>


                        <div class="col-12">
                            <div class="mobile-menu"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- header-end -->
    <!-- offcanvas-area -->
    <div class="offcanvas-menu">
        <span class="menu-close"><i class="fas fa-times"></i></span>
        <form role="search" method="get" id="searchform" class="searchform" action="http://wordpress.zcube.in/xconsulta/">
            <input type="text" name="s" id="search" value="" placeholder="Search" />
            <button><i class="fa fa-search"></i></button>
        </form>


        <div id="cssmenu3" class="menu-one-page-menu-container">
            <ul id="menu-one-page-menu-2" class="menu">
                <li class="menu-item menu-item-type-custom menu-item-object-custom"><a href="index.php">Home</a></li>
                <li class="menu-item menu-item-type-custom menu-item-object-custom"><a href="about.php">About Us</a></li>
                <!-- <li class="menu-item menu-item-type-custom menu-item-object-custom"><a href="courses.html">Quizzes</a></li> -->
                <!-- <li class="menu-item menu-item-type-custom menu-item-object-custom"><a href="pricing.html">Pricing </a></li>
                <li class="menu-item menu-item-type-custom menu-item-object-custom"><a href="team.html">Team </a></li>

                <li class="menu-item menu-item-type-custom menu-item-object-custom"><a href="projects.html">Gallery Study</a></li>
                <li class="menu-item menu-item-type-custom menu-item-object-custom"><a href="blog.html">Blog</a></li> -->
                <li class="menu-item menu-item-type-custom menu-item-object-custom"><a href="contact.php">Contact</a></li>
            </ul>
        </div>

        <div id="cssmenu2" class="menu-one-page-menu-container">
            <ul id="menu-one-page-menu-1" class="menu">
                <li class="menu-item menu-item-type-custom menu-item-object-custom">
                    <a href="logout.php">Logout</a></li>
                <li class="menu-item menu-item-type-custom menu-item-object-custom"><a href="#home"><span>+91 9571538998</span></a></li>
                <li class="menu-item menu-item-type-custom menu-item-object-custom"><a href="#howitwork"><span>hello@peero.in</span></a></li>
            </ul>
        </div>
    </div>
    <div class="offcanvas-overly"></div>
    <!-- offcanvas-end -->

    <!-- main-area -->
    <main>

        <!-- search-popup -->
        <div class="modal fade bs-example-modal-lg search-bg popup1" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content search-popup">
                    <div class="text-center">
                        <a href="#" class="close2" data-dismiss="modal" aria-label="Close">× close</a>
                    </div>
                    <div class="row search-outer">
                        <div class="col-md-11"><input type="text" placeholder="Search for products..." /></div>
                        <div class="col-md-1 text-right"><a href="#"><i class="fa fa-search" aria-hidden="true"></i></a></div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /search-popup -->
        <!-- /search-popup -->
        <!-- breadcrumb-area -->
        <section class="breadcrumb-area d-flex align-items-center" style="background-image:url(img/testimonial/test-bg.png)">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-xl-12 col-lg-12">
                        <div class="breadcrumb-wrap text-left">
                            <div class="breadcrumb-title">
                                <h2>Available Competitions </h2>
                                <div class="breadcrumb-wrap">

                                    <nav aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                            <!-- <li class="breadcrumb-item active" aria-current="page">Pricing</li> -->
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>
        <!-- breadcrumb-area-end -->
        <!-- shop-area -->
        <section class="shop-area pt-120 pb-120 p-relative " style=" background-image: url(img/bg/blog-bg-aliments.png); background-repeat: no-repeat; background-position: center center;background-attachment: fixed;">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-4 col-md-6">
                        <div class="product couress-box mb-40">
                            <div class="product__img">
                                <a href="english.php"><img src="img/gallery/English Page.png" alt=""></a>

                            </div>
                            <div class="product__content pt-30">
                                <ul class="course-meta course-meta2 review style2 clearfix mb-30">
                                    <li class="author">
                                        <div class="thumb">
                                            <!-- <img src="img/testimonial/testi_avatar.png" alt="image"> -->
                                        </div>

                                        <div class="text">
                                            <!-- <p> Teacher :<a href="#"> Robto Jone</a> </p> -->

                                        </div>
                                    </li>


                                </ul>
                                <!-- <div class="price">
                                    $95.00
                                </div> -->
                                <h4 class="pro-title">
                                    <a href="english.php">ENGLISH</a>
                                </h4>
                                <p> English is one of the most influential languages in the world and is the most commonly spoken language with almost 53 countries. </p>
                                <ul class="course-meta desc">
                                    <li>
                                        <h6>Competition</h6>
                                        <span> Type</span>
                                    </li>

                                    <li>
                                        <h6>165</h6>
                                        <span> Enrolled Students</span>
                                    </li>

                                    <li>
                                        <h6><span class="course-time">1.5 Hours</span></h6>
                                        <span>Duration</span>
                                    </li>
                                </ul>

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="product couress-box mb-40">
                            <div class="product__img">
                                <a href="science.php"><img src="img/gallery/Science Page.jpg" alt=""></a>

                            </div>
                            <div class="product__content pt-30">
                                <ul class="course-meta course-meta2 review style2 clearfix mb-30">
                                    <li class="author">
                                        <div class="thumb">
                                            <!-- <img src="img/testimonial/testi_avatar.png" alt="image"> -->
                                        </div>

                                        <!-- <div class="text">
                                            <p> Teacher :<a href="#"> Robto Jone</a> </p>

                                        </div> -->
                                    </li>


                                </ul>
                                <!-- <div class="price">
                                    $95.00
                                </div> -->
                                <h4 class="pro-title"><a href="science.php">SCIENCE</a></h4>
                                <p>Science competitions are the perfect way to engage students, build on their practical skills and test their skills. enhance their skill set. </p>
                                <ul class="course-meta desc">
                                    <li>
                                        <h6>Competition</h6>
                                        <span>Type</span>
                                    </li>

                                    <li>
                                        <h6>130</h6>
                                        <span> Enrolled Students</span>
                                    </li>

                                    <li>
                                        <h6><span class="course-time">1.5 Hour</span></h6>
                                        <span>Duration</span>
                                    </li>
                                </ul>

                            </div>
                        </div>
                    </div>
                    <!-- <div class="col-lg-4 col-md-6">
                        <div class="product couress-box mb-40">
                            <div class="product__img">
                                <a href="courses-details.html"><img src="img/featured-courses/courses-img3.png" alt=""></a>

                            </div>
                            <div class="product__content pt-30">
                                <ul class="course-meta course-meta2 review style2 clearfix mb-30">
                                    <li class="author">
                                        <div class="thumb">
                                            <img src="img/testimonial/testi_avatar.png" alt="image">
                                        </div>

                                        <div class="text">
                                            <a href="#">Robto Jone</a>
                                            <p>Teacher</p>
                                        </div>
                                    </li>


                                </ul>
                                <div class="price">
                                    $95.00
                                </div>
                                <h4 class="pro-title"><a href="courses-details.html">Digital Marketing Course</a></h4>
                                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Tenetur accusamus hic ea in autem debitis minima.</p>
                                <ul class="course-meta desc">
                                    <li>
                                        <h6>1 year</h6>
                                        <span> Course</span>
                                    </li>

                                    <li>
                                        <h6>25</h6>
                                        <span> Class Size</span>
                                    </li>

                                    <li>
                                        <h6><span class="course-time">7:00 - 10:00</span></h6>
                                        <span> Class Duration</span>
                                    </li>
                                </ul>

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="product couress-box mb-40">
                            <div class="product__img">
                                <a href="courses-details.html"><img src="img/featured-courses/courses-img4.png" alt=""></a>

                            </div>
                            <div class="product__content pt-30">
                                <ul class="course-meta course-meta2 review style2 clearfix mb-30">
                                    <li class="author">
                                        <div class="thumb">
                                            <img src="img/testimonial/testi_avatar.png" alt="image">
                                        </div>

                                        <div class="text">
                                            <a href="#">Robto Jone</a>
                                            <p>Teacher</p>
                                        </div>
                                    </li>


                                </ul>
                                <div class="price">
                                    $95.00
                                </div>
                                <h4 class="pro-title"><a href="courses-details.html">React JS, Angular</a></h4>
                                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Tenetur accusamus hic ea in autem debitis minima.</p>
                                <ul class="course-meta desc">
                                    <li>
                                        <h6>1 year</h6>
                                        <span> Course</span>
                                    </li>

                                    <li>
                                        <h6>25</h6>
                                        <span> Class Size</span>
                                    </li>

                                    <li>
                                        <h6><span class="course-time">7:00 - 10:00</span></h6>
                                        <span> Class Duration</span>
                                    </li>
                                </ul>

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="product couress-box mb-40">
                            <div class="product__img">
                                <a href="courses-details.html"><img src="img/featured-courses/courses-img5.png" alt=""></a>

                            </div>
                            <div class="product__content pt-30">
                                <ul class="course-meta course-meta2 review style2 clearfix mb-30">
                                    <li class="author">
                                        <div class="thumb">
                                            <img src="img/testimonial/testi_avatar.png" alt="image">
                                        </div>

                                        <div class="text">
                                            <a href="#">Robto Jone</a>
                                            <p>Teacher</p>
                                        </div>
                                    </li>


                                </ul>
                                <div class="price">
                                    $95.00
                                </div>
                                <h4 class="pro-title"><a href="courses-details.html">Laravel API Development</a></h4>
                                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Tenetur accusamus hic ea in autem debitis minima.</p>
                                <ul class="course-meta desc">
                                    <li>
                                        <h6>1 year</h6>
                                        <span> Course</span>
                                    </li>

                                    <li>
                                        <h6>25</h6>
                                        <span> Class Size</span>
                                    </li>

                                    <li>
                                        <h6><span class="course-time">7:00 - 10:00</span></h6>
                                        <span> Class Duration</span>
                                    </li>
                                </ul>

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="product couress-box mb-40">
                            <div class="product__img">
                                <a href="courses-details.html"><img src="img/featured-courses/courses-img1.png" alt=""></a>

                            </div>
                            <div class="product__content pt-30">
                                <ul class="course-meta course-meta2 review style2 clearfix mb-30">
                                    <li class="author">
                                        <div class="thumb">
                                            <img src="img/testimonial/testi_avatar.png" alt="image">
                                        </div>

                                        <div class="text">
                                            <a href="#">Robto Jone</a>
                                            <p>Teacher</p>
                                        </div>
                                    </li>


                                </ul>
                                <div class="price">
                                    $95.00
                                </div>
                                <h4 class="pro-title"><a href="courses-details.html">Zero to Hero in Python 1</a></h4>
                                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Tenetur accusamus hic ea in autem debitis minima.</p>
                                <ul class="course-meta desc">
                                    <li>
                                        <h6>1 year</h6>
                                        <span> Course</span>
                                    </li>

                                    <li>
                                        <h6>25</h6>
                                        <span> Class Size</span>
                                    </li>

                                    <li>
                                        <h6><span class="course-time">7:00 - 10:00</span></h6>
                                        <span> Class Duration</span>
                                    </li>
                                </ul>

                            </div> -->
                </div>
            </div>


            </div>
            <!-- <div class="row">
                <div class="col-12">
                    <div class="pagination-wrap mt-50 text-center">
                        <nav>
                            <ul class="pagination">
                                <li class="page-item"><a href="#"><i class="fas fa-angle-double-left"></i></a></li>
                                <li class="page-item active"><a href="#">1</a></li>
                                <li class="page-item"><a href="#">2</a></li>
                                <li class="page-item"><a href="#">3</a></li>
                                <li class="page-item"><a href="#">...</a></li>
                                <li class="page-item"><a href="#">10</a></li>
                                <li class="page-item"><a href="#"><i class="fas fa-angle-double-right"></i></a></li>
                            </ul>
                        </nav>
                    </div>
                </div>
                <div></div> -->
            </div>
            </div>
        </section>
        <!-- shop-area-end -->


    </main>
    <!-- main-area-end -->
    <!-- footer -->
    <footer class="footer-bg footer-p fix" style=" background-image: url(img/bg/footer-bg.png); background-repeat: no-repeat; background-position: center;">
        <div class="footer-top  pt-70 pb-40">
            <div class="container">
                <div class="row">
                    <div class="col-xl-3 col-lg-3 col-sm-12">
                        <div class="footer-widget mb-30">

                            <img src="img/logo/f_logo.png" alt="img">

                        </div>
                    </div>
                    <div class="col-xl-7 col-lg-7 col-sm-12">
                        <div class="footer-widget footer-link mt-20 text-center">
                            <ul>
                                <li><a href="index.php">Home</a></li>
                                <li><a href="about.php"> About Us</a></li>
                                <!-- <li><a href="courses.html"> Competet </a></li> -->
                                <!-- <li><a href=""> Events</a></li>
                                <li><a href="blog.html">Blog </a></li> -->
                                <li><a href="contact.php">Contact Us </a></li>
                            </ul>


                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-2 col-sm-12">
                        <div class="footer-widget footer-social mt-15  text-right text-xl-right">
                            <a href="https://www.facebook.com/PeerO.in/ "><i class="fab fa-facebook-f "></i></a>
                            <a href="https://www.instagram.com/peero.in/"><i class="fab fa-instagram "></i></a>
                            <!-- <a href="#"><i class="fab fa-twitter"></i></a> -->

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-center  pt-70 pb-40">
            <div class="container">
                <div class="row justify-content-between">

                    <div class="col-xl-3 col-lg-3 col-sm-6">
                        <div class="footer-widget mb-30">
                            <div class="f-widget-title">
                                <h2>About Us</h2>
                            </div>
                            <div class="footer-link">
                                Need something? Peer’O is here to help. For any queries please contact us on our details below </div>

                        </div>
                    </div>

                    <div class="col-xl-3 col-lg-3 col-sm-6">
                        <div class="footer-widget mb-30">
                            <div class="f-widget-title">
                                <h2>Contact Us</h2>
                            </div>
                            <div class="f-contact">
                                <ul>
                                    <li>
                                        <i class="icon fal fa-map-marker-check "></i>
                                        <span>No.9, 2nd Floor, Kaveri Mansion, HAL, Bangalore, 560017</span>
                                    </li>
                                    <li>
                                        <i class="icon fal fa-phone "></i>
                                        <span>+91 9571538998<br></span>
                                    </li>
                                    <li><i class="icon fal fa-envelope "></i>
                                        <span>
                                            <a href="mailto:info@example.com ">hello@peero.in</a>
                                       <br>
                                       <!-- <a href="mailto:help@example.com ">help@example.com</a> -->
                                       </span>
                                    </li>


                                </ul>

                            </div>
                        </div>
                    </div>



                    <!-- <div class="col-xl-3 col-lg-3 col-sm-6">
                        <div class="footer-widget mb-30">
                            <div class="f-widget-title">
                                <h2>Our Gallery</h2>
                            </div>
                            <div class="f-insta">
                                <ul>
                                    <li>
                                        <a href="img/instagram/f-galler-01.png" class=" popup-image"><img src="img/instagram/f-galler-01.png" alt="img"></a>
                                    </li>
                                    <li>
                                        <a href="img/instagram/f-galler-02.png" class=" popup-image"><img src="img/instagram/f-galler-02.png" alt="img"></a>
                                    </li>
                                    <li>
                                        <a href="img/instagram/f-galler-03.png" class=" popup-image"><img src="img/instagram/f-galler-03.png" alt="img"></a>
                                    </li>
                                    <li>
                                        <a href="img/instagram/f-galler-04.png" class=" popup-image"><img src="img/instagram/f-galler-04.png" alt="img"></a>
                                    </li>

                                </ul>
                            </div>
                        </div>
                    </div> -->

                </div>
            </div>
        </div>
        <div class="copyright-wrap">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6 ">
                        Copyright &copy; 2021 Peero. All rights reserved.
                    </div>
                    <div class="col-lg-6 text-right text-xl-right ">
                        <ul>
                            <li><a href="# ">Privacy</a></li>
                            <li><a href="# ">Term & Conditions</a></li>
                            <li><a href="# ">Legal</a></li>
                        </ul>
                    </div>

                </div>
            </div>
        </div>
    </footer>
    <!-- footer-end -->


    <!-- JS here -->
    <script src="js/vendor/modernizr-3.5.0.min.js"></script>
    <script src="js/vendor/jquery-1.12.4.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/one-page-nav-min.js"></script>
    <script src="js/slick.min.js"></script>
    <script src="js/ajax-form.js"></script>
    <script src="js/paroller.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/js_isotope.pkgd.min.js"></script>
    <script src="js/imagesloaded.min.js"></script>
    <script src="js/parallax.min.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.counterup.min.js"></script>
    <script src="js/jquery.scrollUp.min.js"></script>
    <script src="js/jquery.meanmenu.min.js"></script>
    <script src="js/parallax-scroll.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/element-in-view.js"></script>
    <script src="js/main.js"></script>
</body>

</html>