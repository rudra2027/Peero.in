<?php
    
$showAlert = false; 
$showError = false; 
$exists=false;
    
if($_SERVER["REQUEST_METHOD"] == "POST") {
      
    // Include file which makes the
    // Database Connection.
    include 'config.php';   
    
    $username = $_POST["username"]; 
    $password = $_POST["password"]; 
    $cpassword = $_POST["cpassword"];
    $number = $_POST["number"];
    $email = $_POST["email"];
    $city = $_POST["city"];
    $school = $_POST["school"];
    $class = $_POST["class"];

            
    
    $sql = "Select * from users where email='$email'";
    
    $result = mysqli_query($conn, $sql);
    
    $num = mysqli_num_rows($result); 
    
    // This sql query is use to check if
    // the username is already present 
    // or not in our Database
    if($num == 0) {
        if(($password == $cpassword) && $exists==false) {
    
            $hash = password_hash($password, 
                                PASSWORD_DEFAULT);
                
            // Password Hashing is used here. 
            $sql = "INSERT INTO `users` ( `username`, 
                `password`, `email`,`number`,`city`,`school`,`class`) VALUES ('$username', 
                '$hash','$email','$number','$city','$school','$class')";
    
            $result = mysqli_query($conn, $sql);
    
            if ($result) {
                echo "<script
      type='text/jscript'>alert('You Are Registered Successfuly! Kindly Login to  Move Ahead')
      window.location.href='Login.html';
      </script>"; 
            }
        } 
        else { 
            $showError = "<script
      type='text/jscript'>alert('Passwords do not match')
      window.location.href='registration.html';
      </script>"; 
        }      
    }// end if 
    
   if($num>0) 
   {
      $exists="<script
      type='text/jscript'>alert('Email Already Registered')
      window.location.href='registration.html';
      </script>"; 
   } 
    
}//end if   
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="UTF-8">
    
    <title></title>
    
</head>
<body>
<?php
    
    if($showAlert) {
    
        echo ' <div class="alert alert-success 
            alert-dismissible fade show" role="alert">
    
            <strong>Success!</strong> Your account is 
            now created and you can login. 
            <button type="button" class="close"
                data-dismiss="alert" aria-label="Close"> 
                <span aria-hidden="true">×</span> 
            </button> 
        </div> '; 
    }
    
    if($showError) {
    
        echo ' <div class="alert alert-danger 
            alert-dismissible fade show" role="alert"> 
        <strong>Error!</strong> '. $showError.'
    
       <button type="button" class="close" 
            data-dismiss="alert aria-label="Close">
            <span aria-hidden="true">×</span> 
       </button> 
     </div> '; 
   }
        
    if($exists) {
        echo ' <div class="alert alert-danger 
            alert-dismissible fade show" role="alert">
    
        <strong>Error!</strong> '. $exists.'
        <button type="button" class="close" 
            data-dismiss="alert" aria-label="Close"> 
            <span aria-hidden="true">×</span> 
        </button>
       </div> '; 
     }?>
     <!-- <div class="logmage">
     <span><img  src="img/gallery/login.png"  height="1000px"width="900px" alt="image1" ><span></div>
     <div class="main_div">




         <div class="title">
             <h2>Register Here</h2>

         </div><br><br>
         <div class="social_icons"><a href="#"><i class="fab fa-facebook-f"></i><span>Sign Up With Facebook</span></a>
     <a href="#"><i class="fab fa-google"></i><span>Sign Up With Google</span></a>
 </div>
 <br>
 <hr style="float:left;width:260px"> OR
 <hr style="float:right;width:250px">

 <form action="register.php" method="POST">
     <label> Username<span class="text-danger">*</span> </label>
     <div class="input_box">
         <input type="text" name="username" placeholder="Firstname" size="15" required />
         <div class="icon"><i class="fas fa-male"></i></div>
         <br><br>

         <label> Contact Number<span class="text-danger">*</span> </label>
         <div class="input_box">
             <input type="phone" name="number" placeholder="Mobile Number" size="15" required />
             <div class="icon"> <i class=" fa fa-phone " aria-hidden="true "></i>
             </div>
             <br><br>


             <label>Email<span class="text-danger">*</span></label>
             <div class="input_box"><input type="email" name="email" placeholder="Email or Phone" required>
                 <div class="icon"><i class="fas fa-user"></i></div>
             </div><br><br>
             <label>Password<span class="text-danger">*</span></label>
             <div class="input_box"><input type="password" name="password" placeholder="Password" required>
                 <div class="icon"><i class="fas fa-lock"></i></div>
             </div>
             <br><br>
             <label> Confirm Password<span class="text-danger">*</span></label>
             <div class="input_box"><input type="password" name="cpassword" placeholder=" Re-Type Password" required>
                 <div class="icon"> <i class=" fas fa-key "></i>
                 </div>
             </div>
             <br><br>
             <div class="option_div">
                 <div class="check_box"><input type="checkbox" required><span>Remember me</span></div>
                 <div class="forget_div"><a href="#">Forgot password?</a></div>
             </div>
             <br>
             <div class="input_box button"><input type="submit" value="Register"></div>
             <div class="sign_up">Already Have An Account -
                 <a href="Login.html">Login </a>
             </div>
 </form>-->
 

</body>
</html>